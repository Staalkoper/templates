
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications (id,updated_at,created_at,created_by,edited_by,rel_id,rel_type,notif_count,is_read,module,title,description,content) VALUES('1','2015-10-19 13:39:05','2015-10-19 13:39:05','1','1','0','forms_lists','','0','contact_form','New form entry','You have new form entry','You have new form entry from {SITE_URL}contact-us&lt;br /&gt;&lt;ul&gt;&lt;li&gt;Name: Name&lt;/li&gt;&lt;li&gt;Email: example@example.com&lt;/li&gt;&lt;li&gt;Message: Message&lt;/li&gt;&lt;li&gt;Captcha: captcha&lt;/li&gt;&lt;li&gt;Ip: 212.75.18.168&lt;/li&gt;&lt;/ul&gt;'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications (id,updated_at,created_at,created_by,edited_by,rel_id,rel_type,notif_count,is_read,module,title,description,content) VALUES('2','2015-11-16 09:53:24','2015-11-16 09:53:24','','','1','cart_orders','','0','shop','You have new order','New order is placed from {SITE_URL}checkout','New order in the online shop. Order id: 1'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('1','page','static','home','Home','0','','0','','','1','','','','','index.php','','','','','1','0','0','0','0','','','','','2015-10-08 12:25:59','2015-10-08 12:25:59','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('2','page','static','test','Test','0','','1','','','1','','','','default','layouts__gallery.php','','','','','0','0','0','1','0','','','','b68b846e6d7d6c64054e0abf0a6dc0da4afbcc5d','2015-10-08 12:26:54','2015-10-08 12:26:54','','1','1','2015-10-08 12:26:54','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('3','page','dynamic','shop','Shop','0','','-1','','','1','','','','default','layouts__shop.php','','','','','0','0','1','0','0','','','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','2015-10-21 14:35:59','2015-10-08 12:34:35','','1','1','2015-10-21 14:35:58','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('4','product','','family-camping-tent','Family Camping Tent','3','','2','','
                  <p id="element_1445254459874" class="element">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p>
                ','1','','','','','inherit','','','','','0','0','0','0','0','','','','b364201e47ff06a5837dd2097f56a98a407cfccd','2015-10-19 11:36:53','2015-10-19 11:36:53','','1','1','2015-10-19 11:36:53','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('5','product','','wenzel-alpine-tent-3-person','Wenzel Alpine Tent','3','','3','
        <div class="mw-row shop-product-row" style="height: auto;" id="element_1445437883340">
          <div class="mw-col" style="width: 65%; height: auto;">
            <div class="mw-col-container">
              <module class=" module module-pictures " id="module-picturesf09b9044e086d09e98ff6a7b374f03ae-5" data-mw-title="Picture Gallery" rel="content" template="product_gallery_multiline" data-type="pictures"></module>
</div>
          </div>
          <div class="mw-col" style="width: 35%; height: auto;">
            <div class="mw-col-container">
              <div class="product-description element" id="element_1445437889887">
                <h2 class="edit product-title element nodrop changed" field="title" rel="post">Wenzel Alpine Tent</h2>
                <div class="edit element changed" field="content_body" rel="post">
                  <p class="element" id="element_1445437883334">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p>
                </div>
                <module class="module module module-shop-cart-add" data-mw-title="Add to cart" id="module-shop-cart-add29db78f705f7c2be552645fe2791c02c-5" rel="post" data-type="shop/cart_add"></module>
</div>
            </div>
          </div>
        </div>
      ','
                  <p class="element" id="element_1445437883334">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p>
                ','1','','','','','inherit','','','','','0','0','0','0','0','','','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','2015-10-21 14:35:59','2015-10-19 11:38:36','','1','1','2015-10-19 11:38:36','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('6','product','product','coleman-montana-8-tent','Coleman Montana 8 Tent','3','','4','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','b364201e47ff06a5837dd2097f56a98a407cfccd','2015-10-19 11:41:05','2015-10-19 11:41:04','','1','1','2015-10-19 11:41:04','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('7','page','dynamic','blog','Blog','0','','-2','','','1','','','','default','layouts__blog.php','','','','','0','0','0','0','0','','','','b364201e47ff06a5837dd2097f56a98a407cfccd','2015-10-19 12:54:16','2015-10-19 11:42:16','','1','1','2015-10-19 12:54:16','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('8','post','post','awesome-tent-camping-experiences','Awesome Tent Camping Experiences','7','','5','
            <module class="module module module-pictures" data-mw-title="Picture Gallery" rel="content" data-template="slider" data-type="pictures" id="module-picturesb5728c28d6da0de60f94708ed9bc3e17-9"></module><div class="edit element" field="content_body" rel="content">
              <div class="element">
                <p id="element_1445254963747" class="element" align="justify">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>
              </div>
            </div>
          ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','b364201e47ff06a5837dd2097f56a98a407cfccd','2015-10-19 12:50:05','2015-10-19 11:44:06','','1','1','2015-10-19 11:44:06','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('10','post','post','kayaking-amp-canoeing-virginia-s-waterways','Kayaking &amp; Canoeing Virginia’s Waterways','7','','6','
            <module class="module    module module-pictures" data-mw-title="Picture Gallery" id="module-picturesb5728c28d6da0de60f94708ed9bc3e17-10" data-type="pictures" data-template="slider" rel="content"></module><div class="edit element" field="content_body" rel="content">
              <div id="element_1445269551801" class="element">
                <p id="element_1445269551375" class="element" align="justify">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>
              </div>
            </div>
          ','','1','','','','','inherit','','','','','0','0','0','0','0','','','','b364201e47ff06a5837dd2097f56a98a407cfccd','2015-10-19 15:47:50','2015-10-19 12:54:16','','1','1','2015-10-19 12:54:16','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('11','page','static','contact-us','Contact us','0','','-3','

            <p align="center" class="element" id="element_1445440267137">
                Contact us and share with us you thoughts.
                We will respond as soon as we can.
<br> Thank you!
            </p>

            <p class="element" id="element_1445440267570"><br></p>

            <div class="mw-row contacts-block" style="height: auto;" id="element_1445440259584">
                <div class="mw-col" style="width: 50%; height: auto;">
                     <div class="mw-col-container">
                        <module class="module module-contact-form" data-mw-title="Contact form" id="contact-form" data-type="contact_form"></module>
</div>
                </div>
                <div class="mw-col" style="width: 50%; height: auto;">
                     <div class="mw-col-container">
                        <div class="well contacts-info element" id="element_1445440262396">
                          <div class="edit element" field="content_body" rel="content" id="element_1445440265178">
      						<h3 class="border-title element" id="element_1445440265141">Address</h3>
                            <div class="contacts-icons element" id="element_1445440267572">
        					  <p class="element" id="element_1445440259757">
                                  <span class="symbol"></span>Sofia 1700, Bulgaria, My place #10 </p>
                              <p class="element" id="element_1445440259673">
                                  <span class="glyphicon glyphicon-phone"></span>+1 234-567-890
                              </p>
                            </div>
      					</div>
                      <h3 class="border-title element" id="element_1445440259578">Follow Us</h3>
                      <div class="contacts-icons element" id="element_1445440267573">
                        <p class="element" id="element_1445440263191">
                          <span class="symbol"></span>
                          <a href="https://facebook.com/Microweber">https://facebook.com/Microweber</a>
                        </p>
                        <p class="element" id="element_1445440263511">
                          <span class="symbol"></span>
                          <a href="https://facebook.com/Microweber">https://twitter.com/Microweber</a>
                        </p>
                        <p class="element" id="element_1445440263668">
                          <span class="symbol"></span>
                          <a href="https://plus.google.com/+Microweber/" class="">https://plus.google.com/+Microweber/</a>
                        </p>
                      </div>
                      </div>
                  </div>
              </div>
            </div>
            <p class="element" id="element_1445440267574"><br></p>
<module class="clear element module module-google-maps" data-mw-title="Google Maps" data-type="google_maps" id="google-maps-20151030100635"></module>
','
      						<h3 class="border-title element" id="element_1445440265141">Address</h3>
                            <div class="contacts-icons element">
        					  <p class="element" id="element_1445440259757">
                                  <span class="symbol"></span>Sofia 1700, Bulgaria, My place #10 </p>
                              <p class="element" id="element_1445440259673">
                                  <span class="glyphicon glyphicon-phone"></span>+1 234-567-890
                              </p>
                            </div>
      					','1','','','','default','contacts.php','','','','','0','0','0','0','0','','','','2b0791ec84064d80ef79d75c5d2aedad4a8c530d','2015-10-30 10:07:01','2015-10-19 13:38:43','','1','1','2015-10-19 13:38:43','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('12','page','static','gallery','Gallery','0','','-4','','','1','','','','default','layouts__gallery.php','','','','','0','0','0','0','0','','','','b364201e47ff06a5837dd2097f56a98a407cfccd','2015-10-19 15:44:23','2015-10-19 15:39:42','','1','1','2015-10-19 15:39:42','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','qty','nolimit','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','sku','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','shipping_weight','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','shipping_width','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','shipping_height','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','shipping_depth','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','4','additional_shipping_cost','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('8','2015-10-19 11:41:04','2015-10-19 11:41:04','1','1','6','qty','nolimit','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('9','2015-10-19 11:41:04','2015-10-19 11:41:04','1','1','6','sku','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('10','2015-10-19 11:41:04','2015-10-19 11:41:04','1','1','6','shipping_weight','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('11','2015-10-19 11:41:04','2015-10-19 11:41:04','1','1','6','shipping_width','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('12','2015-10-19 11:41:05','2015-10-19 11:41:05','1','1','6','shipping_height','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('13','2015-10-19 11:41:05','2015-10-19 11:41:05','1','1','6','shipping_depth','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('14','2015-10-19 11:41:05','2015-10-19 11:41:05','1','1','6','additional_shipping_cost','','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('15','2015-10-21 14:35:58','2015-10-21 14:31:39','1','1','5','qty','nolimit','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('16','2015-10-21 14:35:58','2015-10-21 14:31:39','1','1','5','sku','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('17','2015-10-21 14:35:58','2015-10-21 14:31:39','1','1','5','shipping_weight','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('18','2015-10-21 14:35:58','2015-10-21 14:31:39','1','1','5','shipping_width','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('19','2015-10-21 14:35:59','2015-10-21 14:31:39','1','1','5','shipping_height','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('20','2015-10-21 14:35:59','2015-10-21 14:31:39','1','1','5','shipping_depth','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('21','2015-10-21 14:35:59','2015-10-21 14:31:39','1','1','5','additional_shipping_cost','','8ce0acdc0b4a89bc762f5403769bea81f9e96053','content','5'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('1','2015-10-19 11:36:53','2015-10-19 11:36:53','1','1','content','4','content_body','
                  <p id="element_1445254459874" class="element">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p>
                '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('3','2015-10-19 11:59:36','2015-10-19 11:59:36','1','1','content','9','checkout_page','
<h2 id="element_1445255948496" class="element">Complete your orser</h2>
      <module class=" module module-shop-checkout " data-mw-title="Checkout" id="cart_checkout" data-type="shop/checkout"></module>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('6','2015-10-21 14:35:59','2015-10-21 14:35:59','1','1','content','5','title','Wenzel Alpine Tent'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('7','2015-10-21 14:35:59','2015-10-21 14:35:59','1','1','content','5','content_body','
                  <p class="element" id="element_1445437883334">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style="font-weight: 600">Make Web</strong>.</p>
                '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('8','2015-10-21 15:09:12','2015-10-21 15:09:12','1','1','global','0','header-top',' <span>Tale</span> <small>Tell your story</small> '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('9','2015-10-21 15:11:17','2015-10-21 15:11:17','1','1','content','11','content_body','
      						<h3 class="border-title element" id="element_1445440265141">Address</h3>
                            <div class="contacts-icons element">
        					  <p class="element" id="element_1445440259757">
                                  <span class="symbol"></span>Sofia 1700, Bulgaria, My place #10 </p>
                              <p class="element" id="element_1445440259673">
                                  <span class="glyphicon glyphicon-phone"></span>+1 234-567-890
                              </p>
                            </div>
      					'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('2','2015-10-19 11:38:20','2015-10-19 11:38:20','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','5','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/81ibxpP0dLL._SX522__1_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('3','2015-10-19 11:38:20','2015-10-19 11:38:20','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','5','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/91u5robTguL._SX522_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('4','2015-10-19 11:38:20','2015-10-19 11:38:20','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','5','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/81jZuW31ZKL._SX522_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('5','2015-10-19 11:38:21','2015-10-19 11:38:21','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','5','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/81_8vYC28lL._SX522_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('6','2015-10-19 11:38:21','2015-10-19 11:38:21','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','5','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/81ibxpP0dLL._SX522_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('7','2015-10-19 11:41:00','2015-10-19 11:41:00','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6','picture','1','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/71WIIJTA_9L._SL1500_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('8','2015-10-19 11:41:00','2015-10-19 11:41:00','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6','picture','4','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/91QDL1a_LDL._SL1500_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('9','2015-10-19 11:41:00','2015-10-19 11:41:00','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6','picture','3','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/71NP6tozNyL._SL1454_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('10','2015-10-19 11:41:01','2015-10-19 11:41:01','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6','picture','2','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/61_0Z5YmWeL._SL1500_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('11','2015-10-19 11:41:01','2015-10-19 11:41:01','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','6','picture','0','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/61_VxVS7b7L._SL1500_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('13','2015-10-19 15:43:36','2015-10-19 15:43:36','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','12','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1414016642750_7fdd78dc33d9_1_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('14','2015-10-19 15:43:36','2015-10-19 15:43:36','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','12','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1418837013843_a7c16e2854a3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('15','2015-10-19 15:43:37','2015-10-19 15:43:37','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','12','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1437356934129_02f4dc0872ae.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('16','2015-10-19 15:43:37','2015-10-19 15:43:37','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','12','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1438155047396_adbf4a7252ec.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('17','2015-10-19 15:43:38','2015-10-19 15:43:38','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','12','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1444124818704_4d89a495bbae.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('18','2015-10-19 15:43:38','2015-10-19 15:43:38','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','12','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1444527899111_2f218d8864f3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('19','2015-10-19 15:46:53','2015-10-19 15:46:53','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','10','picture','1','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1440993443326_9e9f5aea703a.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('20','2015-10-19 15:47:43','2015-10-19 15:47:43','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','10','picture','2','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1419133203517_f3b3ed0ba2bb.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('21','2015-10-19 15:49:45','2015-10-19 15:49:45','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4','picture','0','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/51K60k0im2L._SX522_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('22','2015-10-19 15:49:46','2015-10-19 15:49:46','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','4','picture','1','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/61j7p4LbWpL._SX522_.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('24','2015-10-19 15:51:15','2015-10-19 15:51:15','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','8','picture','9999999','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1432817495152_77aa949fb1e2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('25','2015-10-19 15:53:44','2015-10-19 15:53:44','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','content','10','picture','0','','','','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/photo_1421885641996_b1f3d004d401.jpg'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('1','content','4','','price','price','price','2015-10-19 11:36:39','2015-10-09 13:15:58','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('2','content','5','','price','price','price','2015-10-21 14:31:49','2015-10-19 11:38:30','1','1','8ce0acdc0b4a89bc762f5403769bea81f9e96053','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('3','content','6','','price','price','price','2015-10-19 11:40:56','2015-10-19 11:40:46','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('4','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-14','0','address','Address','address','2015-10-19 11:59:03','2015-10-19 11:59:03','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('5','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-21','0','address','Address','address','2015-10-19 11:59:03','2015-10-19 11:59:03','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('6','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-25','0','address','Address','address','2015-10-19 11:59:03','2015-10-19 11:59:03','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('7','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-29','0','address','Address','address','2015-10-19 11:59:03','2015-10-19 11:59:03','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('8','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-35','0','address','Address','address','2015-10-19 11:59:03','2015-10-19 11:59:03','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('9','module','shipping-info-module-shop-shipping-gateways-country0ac052d8ad473fff4fc4690cbb37ae99-9','0','address','Address','address','2015-10-19 11:59:10','2015-10-19 11:59:10','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('10','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-9','0','address','Address','address','2015-10-19 11:59:29','2015-10-19 11:59:29','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('11','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-9833053221','0','address','Address','address','2015-10-19 11:59:30','2015-10-19 11:59:30','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('12','content','11','','price','price','price','2015-10-19 13:01:40','2015-10-19 13:01:40','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('13','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-16','0','address','Address','address','2015-10-19 13:13:15','2015-10-19 13:13:15','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('14','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-23','0','address','Address','address','2015-10-19 13:13:15','2015-10-19 13:13:15','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('15','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-27','0','address','Address','address','2015-10-19 13:13:15','2015-10-19 13:13:15','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('16','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-31','0','address','Address','address','2015-10-19 13:13:15','2015-10-19 13:13:15','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('17','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-37','0','address','Address','address','2015-10-19 13:13:15','2015-10-19 13:13:15','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('18','module','contact-form','0','name','Name','name','2015-10-19 13:38:16','2015-10-19 13:38:16','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('19','module','contact-form','1','email','Email','email','2015-10-19 13:38:16','2015-10-19 13:38:16','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('20','module','contact-form','2','message','Message','message','2015-10-19 13:38:16','2015-10-19 13:38:16','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('21','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-17','0','address','Address','address','2015-10-19 14:21:02','2015-10-19 14:21:02','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('22','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-24','0','address','Address','address','2015-10-19 14:21:02','2015-10-19 14:21:02','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('23','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-28','0','address','Address','address','2015-10-19 14:21:02','2015-10-19 14:21:02','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('24','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-32','0','address','Address','address','2015-10-19 14:21:02','2015-10-19 14:21:02','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('25','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-38','0','address','Address','address','2015-10-19 14:21:02','2015-10-19 14:21:02','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('26','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-18','0','address','Address','address','2015-10-19 16:06:05','2015-10-19 16:06:05','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('27','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-33','0','address','Address','address','2015-10-19 16:06:05','2015-10-19 16:06:05','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('28','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-39','0','address','Address','address','2015-10-19 16:06:05','2015-10-19 16:06:05','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('29','module','shipping-info-module-shop-shipping-gateways-country19969e4d6d61e5b5f0b080c2d2c043b4-13','0','address','Address','address','2015-10-19 16:06:42','2015-10-19 16:06:42','1','1','b364201e47ff06a5837dd2097f56a98a407cfccd','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('30','module','shipping-info-module-shop-shipping-gateways-country41c96f72ba5ed99a8745244c8bcd9275-19','0','address','Address','address','2015-11-16 09:53:30','2015-11-16 09:53:30','','','af1375006cddcf996e69c72ab6b78841a3b2f3f3','','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','1','250','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','3','128','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('3','4','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('4','5','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('5','6','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('6','7','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('7','8','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('8','9','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('9','10','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('10','11','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('11','12','0','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('12','13','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('13','14','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('14','15','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('15','16','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('16','17','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('17','18','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('18','19','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('19','20','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('20','21','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('21','22','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('22','23','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('23','24','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('24','25','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('25','26','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('26','27','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('27','28','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('28','29','','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('29','2','200','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('30','30','','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('1','header_menu','menu','','','','','2015-10-08 12:25:59','2015-10-08 12:25:59','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('2','','menu_item','1','1','','0','2015-10-08 12:25:59','2015-10-08 12:25:59','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('3','footer_menu','menu','','','','','2015-10-08 12:25:59','2015-10-08 12:25:59','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('5','','menu_item','1','2','','999999','2015-10-08 12:26:54','2015-10-08 12:26:54','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('6','','menu_item','1','3','','2','2015-10-19 11:38:46','2015-10-19 11:38:46','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('7','','menu_item','1','7','','1','2015-10-19 11:42:16','2015-10-19 11:42:16','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('8','','menu_item','3','7','','999999','2015-10-19 11:42:16','2015-10-19 11:42:16','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('9','','menu_item','1','11','','4','2015-10-19 13:38:43','2015-10-19 13:38:43','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,auto_populate,description,url) VALUES('10','','menu_item','1','12','','3','2015-10-19 15:44:23','2015-10-19 15:44:23','1','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */forms_data (id,created_at,created_by,rel_type,rel_id,list_id,form_values,module_name,url,user_ip) VALUES('1','2015-10-19 13:39:05','1','module','contact-form','0','{&quot;Name&quot;:&quot;Name&quot;,&quot;Email&quot;:&quot;example@example.com&quot;,&quot;Message&quot;:&quot;Message&quot;}','contact_form','','212.75.18.168'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('1','2015-10-08 12:25:56','2015-10-08 12:25:56','current_template','tale','','','','template','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('2','2015-10-08 12:25:59','2015-10-08 12:25:59','website_title','Microweber','','','','website','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('3','2015-10-08 12:25:59','2015-10-08 12:25:59','enable_comments','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('4','2015-10-08 12:25:59','2015-10-08 12:25:59','shipping_gw_shop/shipping/gateways/country','y','','','','shipping','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('5','2015-10-08 12:25:59','2015-10-08 12:25:59','payment_gw_shop/payments/gateways/paypal','1','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('6','2015-10-08 12:25:59','2015-10-08 12:25:59','currency','USD','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('7','2015-10-08 12:27:47','2015-10-08 12:27:16','color-scheme','default','','','','mw-template-liteness','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('8','2015-10-21 15:29:01','2015-10-08 12:53:25','text','   TALE','','','','site-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('9','2015-10-21 14:56:42','2015-10-08 12:53:28','font_family','Montserrat','','','','site-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('10','2015-10-08 12:54:21','2015-10-08 12:54:21','font_size','35','','','','site-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('11','2015-10-09 12:44:27','2015-10-09 12:44:02','header_image','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/island_beach_scenery_wallpaper_1.jpg','','','','mw-template-liteness','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('12','2015-10-30 11:50:08','2015-10-09 12:46:26','header_image','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/_AA5C5AF3C94E91B01D81B5484E2D08228A7F86FDAF1CF753BA_pimgpsh_fullsize_distr.jpg','','','','mw-template-tale','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('13','2015-10-19 15:54:11','2015-10-19 14:03:38','font','Montserrat','','','','mw-template-tale','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('14','2015-10-19 15:52:45','2015-10-19 15:52:40','data-limit','','','','','module-postsb11e6078f4f189d6cf3a51de44a550fd-7','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('15','2015-10-21 15:29:54','2015-10-21 14:55:29','size','45','','','','site-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('16','2015-10-21 15:29:47','2015-10-21 14:55:29','logoimage','{SITE_URL}userfiles/media/tale-lab-microweber-com/uploaded/logo2_1.jpg','','','','site-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('17','2015-10-21 15:07:33','2015-10-21 15:06:04','logotype','both','','','','site-logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('18','2015-10-21 15:10:30','2015-10-21 15:09:47','data-show','thumbnail, title, description, read_more','','','','module-postsb11e6078f4f189d6cf3a51de44a550fd-7','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('19','2015-10-21 15:10:07','2015-10-21 15:10:05','data-hide-paging','','','','','module-postsb11e6078f4f189d6cf3a51de44a550fd-7','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('20','2015-10-30 12:05:13','2015-10-30 12:04:58','data-template','masonry.php','','','','module-shop-products58fa22555bb1e670e20e4f1bd809e390-3','','','','','shop/products',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('1','Coleman Montana 8 Tent','','6','content','2015-10-19 16:06:04','2015-10-19 11:51:35','128.0','','b364201e47ff06a5837dd2097f56a98a407cfccd','5','','0','','','1','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('3','Family Camping Tent','','4','content','2015-10-19 16:06:18','2015-10-19 16:06:18','250.0','','b364201e47ff06a5837dd2097f56a98a407cfccd','1','','0','','','1','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('4','Wenzel Alpine Tent - 3 Person','','5','content','2015-10-19 16:14:58','2015-10-19 16:14:58','0.0','','b364201e47ff06a5837dd2097f56a98a407cfccd','1','','0','','','1','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('5','Coleman Montana 8 Tent','','6','content','2015-10-20 11:04:15','2015-10-20 11:03:58','128.0','','e3b919997edc951be8765e0eea2574b5f043906a','1','','0','','','','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('6','Family Camping Tent','','4','content','2015-10-21 15:59:40','2015-10-21 15:59:40','250.0','','e67e9b123d0cd89882fc86578ba289a958c1e000','1','','0','','','','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('7','Family Camping Tent','','4','content','2015-10-22 12:41:58','2015-10-22 12:41:58','250.0','','79a190cd9da857267b15414e6a41aeb261cce242','1','','0','','','','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('8','Coleman Montana 8 Tent','','6','content','2015-10-30 12:04:18','2015-10-30 10:27:53','128.0','','8e2347b7f1a85825181d15d8027a233dad6861bc','5','','0','','','','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('9','Wenzel Alpine Tent','','5','content','2015-10-30 13:14:44','2015-10-30 13:14:44','200.0','','2009f1c20efa6433e33e3ce820c9ac04019be142','1','','0','','','','W10=',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data,item_image) VALUES('10','Wenzel Alpine Tent','','5','content','2015-11-16 09:55:06','2015-11-16 09:53:09','200.0','','ac43d32937d98e0ea66a9247c6c6b3cf4286fce7','1','','1','1','','','W10=',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders (id,updated_at,created_at,order_id,amount,transaction_id,shipping_service,shipping,currency,currency_code,first_name,last_name,email,country,city,state,zip,address,address2,phone,created_by,edited_by,session_id,order_completed,is_paid,url,user_ip,items_count,custom_fields_data,payment_gw,payment_verify_token,payment_amount,payment_currency,payment_status,payment_email,payment_receiver_email,payment_name,payment_country,payment_address,payment_city,payment_state,payment_zip,payer_id,payer_status,payment_type,order_status,payment_shipping,is_active,rel_id,rel_type,price,other_info,promo_code,skip_promo_code,tax_percent,taxes_amount) VALUES('1','2015-11-16 09:53:24','2015-11-16 09:53:24','','200.0','','shop/shipping/gateways/country','0.0','USD','','first_name','last_name','example@example.com','Albania','Address[city]','Address[state]','90210','Address[address]','','phone','','','af1375006cddcf996e69c72ab6b78841a3b2f3f3','1','0','{SITE_URL}checkout','212.75.18.168','1','','shop/payments/gateways/paypal','ec29a651285f0a75755e24ad40e77cc0','200.0','USD','','','','','','','','','','','','','pending','0.0','','','','','','','','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_shipping (id,updated_at,created_at,is_active,shipping_cost,shipping_cost_max,shipping_cost_above,shipping_country,position,shipping_type,shipping_price_per_size,shipping_price_per_weight,shipping_price_per_item,shipping_price_custom) VALUES('1','2015-10-08 12:25:59','2015-10-08 12:25:59','1','0.0','','','Worldwide','','fixed','','','',''); /* MW_QUERY_SEPERATOR */





