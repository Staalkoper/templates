
REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('1','page','static','home','Home','0','','1','','0','1','','','','default','index.php','','','','','1','0','0','0','0','','','','4591fb92bb8757e6fe8daf3f70d2945ab3876aba','2015-05-24 08:58:29','2015-05-10 13:19:29','','','2','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('2','page','static','contact-us','Contact Us','0','','-4','','','1','','','','default','layouts__contacts.php','','','','','0','0','0','0','0','','','','c63505e60cd6effa0cff8693a6b139199356b112','2015-05-10 13:24:05','2015-05-10 13:23:55','','1','1','2015-05-10 13:23:55','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('3','page','dynamic','blog','Blog','0','','0','','0','1','','','','default','layouts__blog3.php','','','','','0','0','0','0','0','','','','9635714543e02e01bb94fe2da771b201a62dab6d','2015-06-30 19:35:22','2015-05-10 14:40:00','','1','1','2015-06-30 19:35:22','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('4','post','post','tarita-template-firts-microweber-cms-blog-post','Tarita template first blog post ','3','','2','
                    <p class="element" id="element_1435692634840"><span style="color: rgb(37, 37, 37); font-family: sans-serif; font-size: 14px; line-height: 22.3999996185303px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</span></p>
<p class="element" id="element_1435692634840"><br></p>
<table width="580px" style="font-size: 14px; color: rgb(37, 37, 37); font-family: sans-serif; line-height: 22.3999996185303px; background-color: rgb(255, 255, 255);"><tbody><tr><td><br></td></tr></tbody></table>
','0','1','','','','','inherit','','','','','0','0','0','0','0','','','','9635714543e02e01bb94fe2da771b201a62dab6d','2015-06-30 19:35:22','2015-05-10 15:03:29','','1','1','2015-05-10 15:03:29','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('5','post','post','second-tarita-template-blog-post-using-microweber-cms','Tarita template second post  ','3','','3','
  

<div class="element picture " data-mw-title="Picture" id="mwemodule-1431369553838" data-type="picture"><p class="element"><img class="element" src="{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/12.jpg" id="row_1431369553874" style="height: 535.991778006167px; width: 848px;"></p></div>
<p class="element" id="row_1431270479054"><span>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&rsquo;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&rsquo;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</span><br></p>
','','1','','','','','inherit','','','','','0','0','0','0','0','','','','7fac05793256c895acd4f12fb9da25dca8acf063','2015-05-11 18:45:45','2015-05-10 15:06:15','','1','1','2015-05-10 15:06:15','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('6','post','post','tarita-template-third-post','Tarita template third post','3','','4','
  <div class="element picture " data-mw-title="Picture" id="mwemodule-1431369760315" data-type="picture"><p class="element"><img class="element" src="{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/12_4.jpg" id="row_1431369760455" style="height: auto; width: 848px;"></p></div>
<p class="element" id="row_1431369755287"><span style="line-height: 20.7999992370605px;">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don&rsquo;t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn&rsquo;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.</span><br></p>
<div class="element text " data-mw-title="Text" id="mwemodule-1431369758232" data-type="text"><p class="element"></p></div>
','
<div><br></div>
<div>
<table width="580px"><tbody><tr><td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</td></tr></tbody></table>
<table width="580px"><tbody><tr><td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</td></tr></tbody></table>
</div>
','1','','','','','inherit','','','','','0','0','0','0','0','','','','6d82fa53787164c088ee9466a39d3026eebdd9d0','2015-06-30 18:31:46','2015-05-11 18:42:31','','1','1','2015-05-11 18:42:31','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('7','page','static','tarita-blog-version-2','Tarita blog version 2','3','','-1','','0','1','','','','default','layouts__blog2.php','','','','','0','0','0','0','0','','','','1f571f4c902b34280a9399ccf7e46be8555a5783','2015-05-24 11:06:42','2015-05-11 19:16:09','','1','1','2015-05-11 19:16:09','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('8','page','static','tarita-blog-version-3','Tarita blog version 3','3','','-2','','0','1','','','','default','layouts__blog.php','','','','','0','0','0','0','0','','','','1f571f4c902b34280a9399ccf7e46be8555a5783','2015-05-24 09:40:54','2015-05-11 19:16:57','','1','1','2015-05-11 19:16:57','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('9','page','static','services','Services','0','','-3','','','1','','','','default','layouts__services.php','','','','','0','0','0','0','0','','','','c11dc9ff55635d9c808270f70691639b744f618a','2015-05-24 08:35:13','2015-05-23 15:48:21','','1','1','2015-05-23 15:48:21','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('10','page','static','services-layout2','Services layout2','0','','-5','','0','1','','','','default','layouts__services2.php','','','','','0','0','0','0','0','','','','8c228a06922f3ceaa648a51224e0d034556737b6','2015-05-24 13:15:46','2015-05-24 08:58:32','','1','1','2015-05-24 08:58:32','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('11','page','dynamic','blog','Blog','0','','','','','1','','','','default','','','','','','0','0','0','0','0','','','','1f571f4c902b34280a9399ccf7e46be8555a5783','2015-05-24 11:43:59','2015-05-24 11:43:59','','1','1','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('12','page','static','colorful-boxes','Colorful boxes','0','','-6','','','1','','','','default','layouts__examplePages__example_page_cb.php','','','','','0','0','0','0','0','','','','b7a216656c1d03fb5a6e9d4aa064408db8b7b7c1','2015-06-10 21:25:08','2015-06-05 21:49:41','','1','1','2015-06-10 21:25:08','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('13','page','static','panels','Panels','0','','-7','','0','1','','','','default','layouts__examplePages__example_page_panels.php','','','','','0','0','0','0','0','','','','b7a216656c1d03fb5a6e9d4aa064408db8b7b7c1','2015-06-10 20:59:17','2015-06-05 21:50:15','','1','1','2015-06-05 21:50:15','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('14','page','static','timeline','Timeline','12','','-8','','','1','','','','default','layouts__examplePages__example_timeline.php','','','','','0','0','0','0','0','','','','b7a216656c1d03fb5a6e9d4aa064408db8b7b7c1','2015-06-10 21:25:08','2015-06-10 21:19:29','','1','1','2015-06-10 21:19:29','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('15','page','static','index2','Home2','0','','-9','','','1','','','','default','index2.php','','','','','0','0','0','0','0','','','','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','2015-06-14 15:48:01','2015-06-14 11:55:35','','1','1','2015-06-14 11:55:35','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('16','page','static','home3','Home3','0','','-10','','','1','','','','default','index3.php','','','','','0','0','0','0','0','','','','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','2015-06-14 15:53:39','2015-06-14 15:53:04','','1','1','2015-06-14 15:53:04','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('17','page','static','pricing-box','Pricing box','0','','-11','','','1','','','','default','layouts__examplePages__example_page_pb.php','','','','','0','0','0','0','0','','','','45e3595681255cd6258fec1fb66858f67f28924b','2015-06-15 20:21:10','2015-06-15 20:21:10','','1','1','2015-06-15 20:21:10','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('18','page','static','about-us','About us','0','','-12','','0','1','','','','default','layouts__aboutus.php','','','','','0','0','0','0','0','','','','abfcb32b947729b406edf3f82103df1e313e4cf9','2015-06-16 16:25:53','2015-06-15 20:43:48','','1','1','2015-06-15 20:43:48','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('19','page','dynamic','shop','Shop','0','','-13','','','1','','','','default','layouts__shop.php','','','','','0','0','1','0','0','','','','df4332150f289922920c6d4be5214cfc19de3ba9','2015-06-24 09:24:13','2015-06-16 16:40:20','','1','1','2015-06-24 09:24:12','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('20','page','dynamic','sidebar-right','Sidebar right','19','','-14','','','1','','','','default','layouts__shop2.php','','','','','0','0','1','0','0','','','','abfcb32b947729b406edf3f82103df1e313e4cf9','2015-06-16 16:43:40','2015-06-16 16:43:31','','1','1','2015-06-16 16:43:31','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('21','page','dynamic','sidebar-left','Sidebar left','0','','-15','','','1','','','','default','layouts__shop.php','','','','','0','0','1','0','0','','','','df4332150f289922920c6d4be5214cfc19de3ba9','2015-06-24 09:22:07','2015-06-16 16:45:21','','1','1','2015-06-24 09:22:07','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('22','page','static','2-columns-right','2 columns right','0','','-16','','','1','','','','default','layouts__2columnsright.php','','','','','0','0','0','0','0','','','','abfcb32b947729b406edf3f82103df1e313e4cf9','2015-06-16 17:04:29','2015-06-16 17:02:18','','1','1','2015-06-16 17:02:18','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('23','page','static','2-columns-left','2 columns left','0','','-17','','','1','','','','default','layouts__2columnsleft.php','','','','','0','0','0','0','0','','','','abfcb32b947729b406edf3f82103df1e313e4cf9','2015-06-16 17:03:08','2015-06-16 17:03:08','','1','1','2015-06-16 17:03:08','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('24','page','static','gallery','Gallery','0','','-18','','','1','','','','default','layouts__gallery.php','','','','','0','0','0','0','0','','','','00403a28d8dcbf6d3957aff56e9458cb14aca658','2015-06-23 09:44:01','2015-06-23 09:43:57','','1','1','2015-06-23 09:43:57','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('25','product','','live-nation-3-days-of-peace-and-music-carbon','Live Nation 3 Days of Peace and Music Carbon','21','','5','
          <div class="mw-row" style="height: auto;" id="element_1435136139320">
            <div class="mw-col" style="width: 50%; height: auto;">
              <div class="mw-col-container">
                <module class="module module module-pictures" data-mw-title="Picture Gallery" id="module-pictures-editor_tools1167824773" rel="content" template="product_gallery" data-type="pictures"></module>
</div>
            </div>
            <div class="mw-col" style="width: 50%; height: auto;">
              <div class="mw-col-container">
                <div class="product-description element" id="element_1435136142879">
                  <div class="edit element changed" field="content_body" rel="post" id="element_1435136142186">
                    <p class="element" id="element_1435136139316"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  </div>
                  <module class="module module module-shop-cart-add" data-mw-title="Add to cart" id="module-shop-cart-add-editor_tools1706281220" rel="post" data-type="shop/cart_add"></module>
</div>
              </div>
            </div>
          </div>
        ','
                    <p class="element" id="element_1435136139316"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  ','1','','','','','inherit','','','','','0','0','0','0','0','','','','df4332150f289922920c6d4be5214cfc19de3ba9','2015-06-24 09:22:08','2015-06-24 09:22:07','','1','1','2015-06-24 09:22:07','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('26','product','','classic-laundry-green-graphic-t-shirt','Classic Laundry Green Graphic T-Shirt','19','','6','
          <div class="mw-row" style="height: auto;" id="element_1435137761018">
            <div class="mw-col" style="width: 50%; height: auto;">
              <div class="mw-col-container">
                <module class="module module module-pictures" data-mw-title="Picture Gallery" id="module-pictures-editor_tools1167824773" rel="content" template="product_gallery" data-type="pictures"></module>
</div>
            </div>
            <div class="mw-col" style="width: 50%; height: auto;">
              <div class="mw-col-container">
                <div class="product-description element">
                  <div class="edit element changed" field="content_body" rel="post" id="element_1435137761394">
                    <p class="element" id="element_1435137761258"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  </div>
                  <module class="module module module-shop-cart-add" data-mw-title="Add to cart" id="module-shop-cart-add-editor_tools1706281220" rel="post" data-type="shop/cart_add"></module>
</div>
              </div>
            </div>
          </div>
        ','
                    <p class="element" id="element_1435137761258"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  ','1','','','','','inherit','','','','','0','0','0','0','0','','','','df4332150f289922920c6d4be5214cfc19de3ba9','2015-06-24 09:23:15','2015-06-24 09:23:14','','1','1','2015-06-24 09:23:14','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('27','product','','disc-jockey-print-t-shirt','Disc Jockey Print T-Shirt','19','','7','','
                    <p class="element" id="element_1435137843215"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  ','1','','','','','inherit','','','','','0','0','0','0','0','','','','df4332150f289922920c6d4be5214cfc19de3ba9','2015-06-24 09:24:13','2015-06-24 09:24:12','','1','1','2015-06-24 09:24:12','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content (id,content_type,subtype,url,title,parent,description,position,content,content_body,is_active,subtype_value,custom_type,custom_type_value,active_site_template,layout_file,layout_name,layout_style,content_filename,original_link,is_home,is_pinged,is_shop,is_deleted,require_login,status,content_meta_title,content_meta_keywords,session_id,updated_at,created_at,expires_at,created_by,edited_by,posted_at,draft_of,copy_of) VALUES('28','page','static','test','Test','0','','-19','','','1','','','','','inherit','','','','','0','0','0','0','0','','','','a07bbf73d76e86a73838e8285dcdad0470fddefe','2015-06-30 19:23:31','2015-06-30 19:23:31','','3','3','2015-06-30 19:23:31','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('1','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','qty','nolimit','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('2','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','sku','','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('3','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','shipping_weight','','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('4','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','shipping_width','','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('5','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','shipping_height','','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('6','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','shipping_depth','','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('7','2015-06-24 09:22:07','2015-06-24 09:22:07','1','1','25','additional_shipping_cost','','df4332150f289922920c6d4be5214cfc19de3ba9','content','25'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('8','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','qty','nolimit','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('9','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','sku','','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('10','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','shipping_weight','','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('11','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','shipping_width','','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('12','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','shipping_height','','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('13','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','shipping_depth','','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('14','2015-06-24 09:23:14','2015-06-24 09:23:14','1','1','26','additional_shipping_cost','','df4332150f289922920c6d4be5214cfc19de3ba9','content','26'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('15','2015-06-24 09:24:12','2015-06-24 09:24:12','1','1','27','qty','nolimit','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('16','2015-06-24 09:24:12','2015-06-24 09:24:12','1','1','27','sku','','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('17','2015-06-24 09:24:13','2015-06-24 09:24:13','1','1','27','shipping_weight','','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('18','2015-06-24 09:24:13','2015-06-24 09:24:13','1','1','27','shipping_width','','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('19','2015-06-24 09:24:13','2015-06-24 09:24:13','1','1','27','shipping_height','','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('20','2015-06-24 09:24:13','2015-06-24 09:24:13','1','1','27','shipping_depth','','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data (id,updated_at,created_at,created_by,edited_by,content_id,field_name,field_value,session_id,rel_type,rel_id) VALUES('21','2015-06-24 09:24:13','2015-06-24 09:24:13','1','1','27','additional_shipping_cost','','df4332150f289922920c6d4be5214cfc19de3ba9','content','27'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('104','2015-06-10 21:05:57','2015-06-10 21:05:57','1','1','example_page_panels','13','example_page_panels','
        <module class=" module module-breadcrumb " id="module-breadcrumb-panels868221781" data-mw-title="Breadbrumb navigation" data-type="breadcrumb"></module><a>
        <div class="container wrapper element" id="row_1433970345682">
            <div class="purchase element" id="row_1433970346348">
                <div class="container element">
                    <div class="row element" id="row_1433970344677">
                        <div class="col-md-12 animated fadeInLeft" style="height: auto;">
                            <span style="text-align: center;">Panels</span>
                            <p class="element" id="row_1433970344408" style="text-align: center;">Colorful solution for your content. Just choose a color and fill it!</p>
                        </div>
                    </div>
                </div>

            </div>
            <module class=" module module-panels " id="module-panels-panels1062294211" template="aqua" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels1119931349" template="blue" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels-1089160650" template="brown" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels177472996" template="Danger" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels587500855" template="dark" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels860453782" template="dark-blue" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels-1429420688" template="default" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels2144551990" template="gray" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels-1290942323" template="green" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels1543332370" template="info" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels1458076221" template="light-green" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels1018845623" template="lightgreen" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels1099762654" template="orange" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels1058565346" template="purple" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels779441242" template="Sea" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels-1943696720" template="Success" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels-1866536040" template="Warning" data-type="panels"></module><module class=" module module-panels " id="module-panels-panels-345934777" template="yellow" data-type="panels"></module>
</div>
    </a>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('105','2015-06-10 21:54:02','2015-06-10 21:54:02','1','1','timeline','14','timeline','
<a>
            <div class="purchase element" id="row_1433973206850">
                <div class="container element">
                    <div class="row element" id="row_1433973205708">
                        <div class="col-md-12 animated fadeInLeft" style="height: auto;">
                            <span class="mw-font-size mw-font-size " style="text-align: center;">Timeline</span>
                            <p class="element" id="row_1433973205717"><span class="mw-font-size mw-font-size " style="text-align: center; font-size: 14px;">Beautiful way to show your posts!</span></p>
                        </div>
                    </div>
                </div>

            </div>


        </a><div class="content-holder element">
<a>
            </a><module class="module module-timeline" id="module-timeline-timeline-1341441334" data-mw-title="Timeline" data-type="timeline"></module><module class=" module module-timeline " id="module-timeline-timeline1990349789" data-mw-title="Timeline" template="timeline2" data-type="timeline"></module>
</div>
        '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('107','2015-06-15 20:18:08','2015-06-15 20:18:08','1','1','pb2','10','pb2','
        <div class="pricing hover-effect">
            <div class="sticker-right">50%<i class="fa fa-gift"></i>
</div>
            <div class="pricing-head">
                <h3>Pro</h3>
                <h4>
<i>$</i>50<i>.00</i> <span>Per Month</span>
</h4>
                <h6>Labore et dolore magnaras </h6>
            </div>
            <ul class="pricing-content list-unstyled">
<li class="bg-color">
<i class="fa fa-location-arrow"></i>Free customisation<span><i class="fa fa-check"></i></span>
</li>
                <li>
<i class="fa fa-inbox"></i> 24 hour support<span><i class="fa fa-check"></i></span>
</li>
                <li class="bg-color">
<i class="fa fa-globe"></i> 10 GB Disckspace<span><i class="fa fa-check"></i></span>
</li>
                <li>
<i class="fa fa-cloud-upload"></i> Cloud Storage<span><i class="fa fa-check"></i></span>
</li>
                <li class="bg-color">
<i class="fa fa-cloud"></i> Online Protection<span><i class="fa fa-check"></i></span>
</li>
            </ul>
<div class="pricing-footer">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cloud Storage magna psum olor.</p>
                <a class="btn-u" href="#"><i class="fa fa-shopping-cart"></i> Purchase Now</a>
            </div>
        </div>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('108','2015-06-15 20:21:10','2015-06-15 20:21:10','1','1','services210','10','services2','
        
        <div class="container content-sm element" id="element_1434399451660">
            <div class="text-center margin-bottom-50 element" id="element_1434399451728">
                <h2 class="title-v2 title-center element" id="element_1434399451760">OUR SERVICES</h2>
                <p class="space-lg-hor element" id="element_1434399451737">If you are going to use a <span class="color-green">passage of Lorem Ipsum</span>, you need to be sure there isn&rsquo;t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making <span class="color-green">this the first</span> true generator on the Internet.</p>
            </div>

            <div class="row news-v2 element">
                <div class=" element">
                    <module class="module module-posts" data-mw-title="Posts List" id="services10" template="normalview" data-type="posts"></module>
</div>
            </div>
        </div>
        

        
        <module class="module module-paralaxblock" id="paralaxblock10" data-type="paralaxblock"></module><div class="container content-sm element" id="element_1434399447333">
            <div class="row element">
                <div class="col-md-4" style="padding-right: 0px; padding-left: 0px; height: auto;">
                    <module class=" module module-boxes " id="box110" data-type="boxes"></module>
</div>
                <div class="col-md-4" style="padding-right: 0px; padding-left: 0px; height: auto;">
                    <module class=" module module-boxes " id="box210" data-type="boxes"></module>
</div>
                <div class="col-md-4" style="padding-right: 0px; padding-left: 0px; height: auto;">
                    <module class="module module-boxes" id="box310" data-type="boxes"></module>
</div>
            </div>
        <div class="row element">
            <div class="col-md-6" style="padding-right: 0px; padding-left: 0px; height: auto;">
                <module class=" module module-boxes " id="box410" data-type="boxes"></module>
</div>
            <div class="col-md-6" style="padding-right: 0px; padding-left: 0px; height: auto;">
                <module class=" module module-boxes " id="box510" data-type="boxes"></module>
</div>
        </div>
        </div>
        
        <div class="container content-sm element" id="element_1434399447158">
        <div class="row element">
            <div class="col-md-4" style="padding-right: 0px; padding-left: 0px; height: auto;">
                <module class=" module module-pricingtables " id="pb1" data-type="pricingtables"></module>
</div>
            <div class="col-md-4" style="padding-right: 0px; padding-left: 0px; height: auto;">
                <module class="module module-pricingtables" id="pb2" data-type="pricingtables"></module>
</div>
            <div class="col-md-4" style="padding-right: 0px; padding-left: 0px; height: auto;">
                <module class="module   module module-pricingtables" id="pb4" data-type="pricingtables"></module>
</div>
        </div>
        </div>

        <div class="parallax-counter-v2 parallaxBg1 element" style="background-position: 50% 90px;" id="element_1434399450671">
            <div class="container element">
                <ul class="row list-row">
<li class="col-md-3 col-sm-6 col-xs-12 md-margin-bottom-30" style="height: auto;">
                        <div class="counters rounded element">
                            <span class="counter">18298</span>
                            <h4 class="text-transform-normal element">Web Developers</h4>
                        </div>
                    </li>
                    <li class="col-md-3 col-sm-6 col-xs-12 md-margin-bottom-30" style="height: auto;">
                        <div class="counters rounded element">
                            <span class="counter">24583</span>
                            <h4 class="text-transform-normal element">Designers</h4>
                        </div>
                    </li>
                    <li class="col-md-3 col-sm-6 col-xs-12 sm-margin-bottom-30" style="height: auto;">
                        <div class="counters rounded element">
                            <span class="counter">37904</span>
                            <h4 class="text-transform-normal element">Open Contests</h4>
                        </div>
                    </li>
                    <li class="col-md-3 col-sm-6 col-xs-12" style="height: auto;">
                        <div class="counters rounded element">
                            <span class="counter">50892</span>
                            <h4 class="text-transform-normal element">Happy Customors</h4>
                        </div>
                    </li>
                </ul>
</div>
        </div>
        <span class="mw-icon-bin mw-icon-changeble"></span> <p class="iconfeature-holder mw-icon-truck mw-icon-changeble element"> 
        </p>
        

        
        <div class="call-action-v1 bg-color-red element">
            <div class="container element">
                <div class="call-action-v1-box element">
                    <div class="call-action-v1-in element">
                        <p class="color-light element">Creative technology company providing key digital services and focused on helping our clients to build a successful business on web and mobile.</p>
                    </div>
                    <div class="call-action-v1-in inner-btn page-scroll element"><p class="element">
                        <a href="#portfolio" class="btn-u btn-brd btn-brd-hover btn-u-light btn-u-block"><span class="mw-icon-bin"></span> Contact us</a>
                    </p></div>
                </div>
            </div>
        </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('109','2015-06-15 20:28:07','2015-06-15 20:28:07','1','1','example_page_pb1','17','example_page_pb1','
        <div class="container wrapper element">
            <div class="purchase element" id="element_1434400035043">
                <div class="container element">
                    <div class="row element" id="element_1434400036728">
                        <div class="col-md-12 animated fadeInLeft" style="height: auto;">
                            <span>Pricing Boxes</span>

                            <p class=" element" id="element_1434400036771">Show the offers with style!</p>
                        </div>
                    </div>
                </div>

            </div>

            <div class="row element" id="element_1434400036018">
                <div class="col-md-4" style="height: auto;">
                    <module class=" module module-pricingtables " id="pb21" data-type="pricingtables"></module>
</div>
                <div class="col-md-4" style="height: auto;">
                    <module class="module module-pricingtables" id="pb212" data-type="pricingtables"></module>
</div>
                <div class="col-md-4" style="height: auto;">
                    <module class="module   module module-pricingtables" id="pb213" data-type="pricingtables"></module>
</div>
            </div>
            <div class="row element">
                <div class="col-sm-12" style="height: auto;">
                    <module class=" module module-pricingtables " template="megaprice" id="pb211" data-type="pricingtables"></module>
</div>
            </div>

        </div>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('110','2015-06-15 20:28:07','2015-06-15 20:28:07','1','1','pb212','17','pb212','
    <div class="pricing hover-effect">
        <div class="pricing-head">
            <h3>Pro</h3>
            <h4>
<i>$</i>44<i>.90</i> <span>Per Month</span>
</h4>
            <h6>Labore et dolore magnaras </h6>
        </div>
        <ul class="pricing-content list-unstyled">
<li class="bg-color">
<i class="fa fa-location-arrow"></i>Free customisation<span><i class="fa fa-check"></i></span>
</li>
            <li>
<i class="fa fa-inbox"></i> 24 hour support<span><i class="fa fa-check"></i></span>
</li>
            <li class="bg-color">
<i class="fa fa-globe"></i> 10 GB Disckspace<span><i class="fa fa-check"></i></span>
</li>
            <li>
<i class="fa fa-cloud-upload"></i> Cloud Storage<span><i class="fa fa-check"></i></span>
</li>
            <li class="bg-color">
<i class="fa fa-cloud"></i> Online Protection<span><i class="fa fa-check"></i></span>
</li>
        </ul>
<div class="pricing-footer">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cloud Storage magna psum olor.</p>
            <a class="btn-u" href="#"><i class="fa fa-shopping-cart"></i> Purchase Now</a>
        </div>
    </div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('111','2015-06-15 20:28:07','2015-06-15 20:28:07','1','1','pb211','17','pb211','
<div class="row no-space-pricing pricing-mega-v1">
<div class="col-md-4 col-sm-6 hidden-sm hidden-xs" style="height: auto;">
    <div class="pricing hidden-area">
        <div class="pricing-head ">
            <h4 class="price">Pay Monthly</h4>
        </div>
        <ul class="pricing-content list-unstyled">
<li class="bg-color">
                <i class="fa fa-users"></i>Advance Payment
            </li>
            <li>
                <i class="fa fa-cloud-upload"></i>Diskspace
            </li>
            <li class="bg-color">
                <i class="fa fa-briefcase"></i>Subdomains
            </li>
            <li>
                <i class="fa fa-envelope"></i>Email Addresses
            </li>
            <li class="bg-color">
                <i class="fa fa-inbox"></i> MySQL Databases
            </li>
            <li>
                <i class="fa fa-gift"></i>Google AdWords Credits
            </li>
            <li class="bg-color">
                <i class="fa fa-leaf"></i>Remote Desktop Widge
            </li>
            <li>
                <i class="fa fa-location-arrow"></i>Message from Users List
            </li>
            <li class="bg-color">
                <i class="fa fa-globe"></i>Google Adwords Voucher
            </li>
            <li>
                <i class="fa fa-dashboard"></i>Scheduled Lock Screen
            </li>
            <li class="bg-color">
                <i class="fa fa-wrench"></i>Customisable Toolbar
            </li>
            <li>
                <i class="fa fa-cogs"></i>Ports Controls
            </li>
            <li class="bg-color">
                <i class="fa fa-gavel"></i>Premium DNS
            </li>
            <li>
                <i class="fa fa-umbrella"></i>SSL Certificate
            </li>
            <li class="bg-color">
                <i class="fa fa-phone"></i>Worldwide Phone Support
            </li>
        </ul>
</div>
</div>
<div class="col-md-2 col-sm-6 block" style="height: auto;">
    <div class="pricing">
        <div class="pricing-head">
            <h3>
                Begginer<span>Officia deserunt mollitia</span>
            </h3>
            <h4 class="price">
                <i>$</i>9<i>.49</i>
                <span class="hidden-md hidden-lg">Per Month</span>
            </h4>
        </div>
        <ul class="pricing-content list-unstyled ">
<li class="bg-color">
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Credit Card Requirement</span>
            </li>
            <li>
                5 GB<span class="hidden-md hidden-lg">Diskspace</span>
            </li>
            <li class="bg-color">
                10<span class="hidden-md hidden-lg">Subdomains</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Email Addresses</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg"> MySQL Databases</span>
            </li>
            <li>
                $50<span class="hidden-md hidden-lg">Google AdWords Credits</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Remote Desktop Widge</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Message from Users List</span>
            </li>
            <li class="bg-color">
                $25<span class="hidden-md hidden-lg">Google Adwords Voucher</span>
            </li>
            <li>
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Scheduled Lock Screen</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-times">
                </i><span class="hidden-md hidden-lg">Customisable Toolbar</span>
            </li>
            <li>
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Ports Controls</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Premium DNS</span>
            </li>
            <li>
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">SSL Certificate</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Worldwide Phone Support</span>
            </li>
        </ul>
<div class="btn-group btn-group-justified">
            <button type="button" class="btn-u btn-block dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-shopping-cart"></i>
                Sign Up
                <i class="fa fa-angle-down"></i>
            </button>
            <ul class="dropdown-menu" role="menu">
<li><a href="#">14 day Free Trial </a></li>
                <li><a href="#">$ 9.48 One Month</a></li>
                <li><a href="#">$ 50.00 Six Month</a></li>
                <li><a href="#">$ 99.99 One Year</a></li>
            </ul>
</div>
    </div>
</div>
<div class="col-md-2 col-sm-6 block" style="height: auto;">
    <div class="pricing">
        <div class="pricing-head">
            <h3> Pro <span>Officia deserunt mollitia</span>
            </h3>
            <h4 class="price">
                <i>$</i>29<i>.95</i>
                <span class="hidden-md hidden-lg">Per Month</span>
            </h4>
        </div>
        <ul class="pricing-content list-unstyled ">
<li class="bg-color">
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Credit Card Requirement</span>
            </li>
            <li>
                15 GB<span class="hidden-md hidden-lg">Diskspace</span>
            </li>
            <li class="bg-color">
                50<span class="hidden-md hidden-lg">Subdomains</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Email Addresses</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg"> MySQL Databases</span>
            </li>
            <li>
                $100<span class="hidden-md hidden-lg">Google AdWords Credits</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Remote Desktop Widge</span>
            </li>
            <li>
                <i class="fa fa-check">
                </i><span class="hidden-md hidden-lg">Message from Users List</span>
            </li>
            <li class="bg-color">
                $75<span class="hidden-md hidden-lg">Google Adwords Voucher</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Scheduled Lock Screen</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Customisable Toolbar</span>
            </li>
            <li>
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Ports Controls</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-times">
                </i><span class="hidden-md hidden-lg">Premium DNS</span>
            </li>
            <li>
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">SSL Certificate</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Worldwide Phone Support</span>
            </li>
        </ul>
<div class="btn-group btn-group-justified">
            <button type="button" class="btn-u btn-block dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-shopping-cart"></i>
                Sign Up
                <i class="fa fa-angle-down"></i>
            </button>
            <ul class="dropdown-menu" role="menu">
<li><a href="#">14 Day Free Trial </a></li>
                <li><a href="#">$ 29.95 One Month</a></li>
                <li><a href="#">$ 99.00 Six Month</a></li>
                <li><a href="#">$ 180.99 One Year</a></li>
            </ul>
</div>
    </div>
</div>
<div class="col-md-2 col-sm-6 block" style="height: auto;">
    <div class="pricing">
        <div class="pricing-head">
            <h3>
                Premium <span>Officia deserunt mollitia</span>
            </h3>
            <h4 class="price">
                <i>$</i>69<i>.99</i>
                <span class="hidden-md hidden-lg">Per Month</span>
            </h4>
        </div>
        <ul class="pricing-content list-unstyled ">
<li class="bg-color">
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Credit Card Requirement</span>
            </li>
            <li>
                50 GB<span class="hidden-md hidden-lg">Diskspace</span>
            </li>
            <li class="bg-color">
                150<span class="hidden-md hidden-lg">Subdomains</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Email Addresses</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg"> MySQL Databases</span>
            </li>
            <li>
                $200<span class="hidden-md hidden-lg">Google AdWords Credits</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Remote Desktop Widge</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Message from Users List</span>
            </li>
            <li class="bg-color">
                $250<span class="hidden-md hidden-lg">Google Adwords Voucher</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Scheduled Lock Screen</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Customisable Toolbar</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Ports Controls</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">Premium DNS</span>
            </li>
            <li>
                <i class="fa fa-times"></i>
                <span class="hidden-md hidden-lg">SSL Certificate</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Worldwide Phone Support</span>
            </li>
        </ul>
<div class="btn-group btn-group-justified">
            <button type="button" class="btn-u btn-block dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-shopping-cart"></i>
                Sign Up
                <i class="fa fa-angle-down"></i>
            </button>
            <ul class="dropdown-menu" role="menu">
<li><a href="#">14 Day Free Trial </a></li>
                <li><a href="#">$ 69.99 One Month</a></li>
                <li><a href="#">$ 250.50 Six Month</a></li>
                <li><a href="#">$ 420.99 One Year</a></li>
            </ul>
</div>
    </div>
</div>
<div class="col-md-2 col-sm-6 block" style="height: auto;">
    <div class="pricing">
        <div class="pricing-head">
            <h3>
                Elite <span>Officia deserunt mollitia</span>
            </h3>
            <h4 class="price">
                <i>$</i>99<i>.00</i>
                <span class="hidden-md hidden-lg">Per Month</span>
            </h4>
        </div>
        <ul class="pricing-content list-unstyled ">
<li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Credit Card Requirement</span>
            </li>
            <li>
                Unlimited<span class="hidden-md hidden-lg">Diskspace</span>
            </li>
            <li class="bg-color">
                2000<span class="hidden-md hidden-lg">Subdomains</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Email Addresses</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg"> MySQL Databases</span>
            </li>
            <li>
                $500<span class="hidden-md hidden-lg">Google AdWords Credits</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Remote Desktop Widge</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Message from Users List</span>
            </li>
            <li class="bg-color">
                $750<span class="hidden-md hidden-lg">Google Adwords Voucher</span>
            </li>
            <li>
                <i class="fa fa-check">
                </i><span class="hidden-md hidden-lg">Scheduled Lock Screen</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Customisable Toolbar</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Ports Controls</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Premium DNS</span>
            </li>
            <li>
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">SSL Certificate</span>
            </li>
            <li class="bg-color">
                <i class="fa fa-check"></i>
                <span class="hidden-md hidden-lg">Worldwide Phone Support</span>
            </li>
        </ul>
<div class="btn-group btn-group-justified">
            <button type="button" class="btn-u btn-block dropdown-toggle" data-toggle="dropdown">
                <i class="fa fa-shopping-cart"></i>
                Sign Up
                <i class="fa fa-angle-down"></i>
            </button>
            <ul class="dropdown-menu" role="menu">
<li><a href="#">14 Day Free Trial </a></li>
                <li><a href="#">$ 99.99 One Month</a></li>
                <li><a href="#">$ 500.50 Six Month</a></li>
                <li><a href="#">$ 800.99 One Year</a></li>
            </ul>
</div>
    </div>
</div>
</div>
'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('112','2015-06-16 10:51:36','2015-06-16 10:51:36','1','1','cleaner','18','cleaner','


        <div class="container content element" id="element_1434449381922">
            <div class="title-box-v2 element">
                <h2 class=" element" id="element_1434449381864">About <span class="color-green">Us</span>
</h2>
                <p class="element" id="element_1434449381879">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>

            
            <div class="shadow-wrapper margin-bottom-50 element" id="element_1434449383868">
<module class="module module-pictures" data-mw-title="Picture Gallery" id="picsliderbig" data-type="pictures"></module>
</div>
            

            
            <div class="row element" id="element_1434449382139">
                <div class="col-md-8" style="height: auto;">
                    <div class="row element" id="element_1434449382210">
                        <div class="col-sm-4" style="height: auto;">
                            <img alt="" src="{SITE_URL}userfiles/templates/tarita/assets/img/main/6.jpg" class="img-responsive margin-bottom-20">
</div>
                        <div class="col-sm-8" style="height: auto;">
                            <p class=" element" id="element_1434449383965">Unify is an incredibly beautiful responsive Bootstrap Template for corporate and creative professionals. It works on all major web browsers, tablets and phone.</p>
                            <ul class="list-unstyled margin-bottom-20">
<li>
<i class="fa fa-check color-green"></i> Donec id elit non mi porta gravida</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Responsive Bootstrap Template</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                            </ul>
</div>
                    </div>

                    <blockquote class="hero-unify">
                        <p class=" element">Award winning digital agency. We bring a personal and effective approach to every project we work on, which is why. Unify is an incredibly beautiful responsive Bootstrap Template for corporate professionals.</p>
                        <small>CEO, Jack Bour</small>
                    </blockquote>
                </div>


                <div class="col-md-4" style="height: auto;">
                    <h3 class="heading-xs no-top-space element" id="element_1434449384147">Web Design <span class="pull-right">88%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 88%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="88" role="progressbar" class="progress-bar progress-bar-u element"><p class="element">
                        </p></div>
                    </div>

                    <h3 class="heading-xs no-top-space element" id="element_1434449384254">PHP/WordPress <span class="pull-right">76%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 76%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="76" role="progressbar" class="progress-bar progress-bar-u element" id="element_1434449384367"><p class="element">
                        </p></div>
                    </div>

                    <h3 class="heading-xs no-top-space element" id="element_1434449384430">HTML/CSS <span class="pull-right">97%</span>
</h3>
                    <div class="progress progress-u progress-xs element" id="element_1434449385107">
                        <div style="width: 97%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="97" role="progressbar" class="progress-bar progress-bar-u element" id="element_1434449384521"><p class="element">
                        </p></div>
                    </div>

                    <h3 class="heading-xs no-top-space element" id="element_1434449384557">Web Animation <span class="pull-right">68%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 68%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="68" role="progressbar" class="progress-bar progress-bar-u element"><p class="element">
                        </p></div>
                    </div>
                </div>

            </div>
            
        </div>
        

        
        <div class="parallax-bg parallaxBg1 element" id="element_1434449386173">
            <div class="container content parallax-about element">
                <div class="title-box-v2 element">
                    <h2 class=" element">About our company</h2>
                    <p class=" element">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>

                <div class="row element" id="element_1434449386052">
                    <div class="col-md-6" style="height: auto;">
                        <div class="banner-info light margin-bottom-10 element" id="element_1434449386315">
                            <i class="rounded-x icon-bell"></i>
                            <div class="overflow-h element" id="element_1434449386731">
                                <h3 class=" element" id="element_1434449386326">Our mission</h3>
                                <p class=" element" id="element_1434449386083">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus tincidunt sit amet dui auctor pellentesque. Nulla ut posuere purus.</p>
                            </div>
                        </div>
                        <div class="banner-info light margin-bottom-10 element" id="element_1434449386349">
                            <i class="rounded-x fa fa-magic"></i>
                            <div class="overflow-h element">
                                <h3 class=" element" id="element_1434449387783">Our vision</h3>
                                <p class="element" id="element_1434449386361">Phasellus vitae rhoncus ipsum. Aliquam ultricies, velit sit amet scelerisque tincidunt, dolor neque consequat est, a dictum felis metus eget nulla.</p>
                            </div>
                        </div>
                        <div class="banner-info light margin-bottom-10 element" id="element_1434449386407">
                            <i class="rounded-x fa fa-thumbs-o-up"></i>
                            <div class="overflow-h element">
                                <h3 class=" element">We are good at ...</h3>
                                <p class=" element">Nunc ac ligula ut diam rutrum porttitor. Integer et neque at lacus placerat pretium eu ac dui. Class aptent taciti sociosqu ad litora torquent per conubia nostra.</p>
                            </div>
                        </div>
                        <div class="margin-bottom-20 element"><p class="element"></p></div>
                    </div>
                    <div class="col-md-6" style="height: auto;">
                        <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/mockup/1.png" alt="" id="element_1434449387967">
</div>
                </div>
            </div>

        </div>
        

        
        <div class="container content element" id="element_1434449388454">
            <div class="title-box-v2 element">
                <h2 class=" element">Company <span class="color-green">life</span>
</h2>
                <p class=" element">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>

            <div class="row margin-bottom-40 element" id="element_1434449388470">
                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element" id="element_1434449388488">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.3.jpg" alt="" id="element_1434449388579"><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <div class="responsive-video element" id="element_1434449388597"><p class="element">
                            
                        </p></div>
                        <p class=" element" id="element_1434449389621">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <div data-ride="carousel" class="carousel slide element" id="carousel-example-generic">
                            <ol class="carousel-indicators">
<li data-slide-to="0" data-target="#carousel-example-generic" class="rounded-x">
                                </li>
<li data-slide-to="1" data-target="#carousel-example-generic" class="rounded-x active">
                                </li>
<li data-slide-to="2" data-target="#carousel-example-generic" class="rounded-x">
                            </li>
</ol>
<div class="carousel-inner element">
                                <div class="item element"><p class="element">
                                    <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-4.1.jpg" alt=""></p></div>
                                <div class="item active element" id="element_1434449389152"><p class="element" id="element_1434449388751">
                                    <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-3.2.jpg" alt=""></p></div>
                                <div class="item element"><p class="element">
                                    <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-4.3.jpg" alt=""></p></div>
                            </div>
                        </div>
                        <p class="element" id="element_1434449389167">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element" id="element_1434449389361">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-2.3.jpg" alt=""><p class="element" id="element_1434449389347">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                
            </div>

            <div class="row element" id="element_1434449388426">
                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <div data-ride="carousel" class="carousel slide element" id="carousel-example-generic-2">
                            <ol class="carousel-indicators">
<li data-slide-to="0" data-target="#carousel-example-generic-2" class="rounded-x">
                                </li>
<li data-slide-to="1" data-target="#carousel-example-generic-2" class="rounded-x active">
                                </li>
<li data-slide-to="2" data-target="#carousel-example-generic-2" class="rounded-x">
                            </li>
</ol>
<div class="carousel-inner element">
                                <div class="item element"><p class="element">
                                    <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-3.1.jpg" alt=""></p></div>
                                <div class="item active element"><p class="element">
                                    <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-3.3.jpg" alt=""></p></div>
                                <div class="item element"><p class="element">
                                    <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-2.1.jpg" alt=""></p></div>
                            </div>
                        </div>
                        <p class=" element" id="element_1434449388445">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element" id="element_1434449388407">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element" id="element_1434449388386">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-2.2.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <div class="responsive-video element"><p class="element">
                            
                        </p></div>
                        <p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                
            </div>
        </div>

        

        
        <div class="parallax-team parallaxBg element" id="element_1434449392360">
            <div class="container content element">
                <div class="title-box-v2 element" id="element_1434449390636">
                    <h2 class="element" id="element_1434449390281">Build Your <span class="color-green">Own</span> Talents</h2>
                    <p class="element" id="element_1434449390643">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>

                <div class="row element" id="element_1434449390024">
                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element" id="element_1434449390236">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/1.jpg" alt=""><div class="inner-team element" id="element_1434449390168">
                                <h3 class="element" id="element_1434449390183">Jack Anderson</h3>
                                <small class="color-green">CEO, Chief Officer</small>
                                <p class=" element">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li>
                                        <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                </ul>
</div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element" id="element_1434449390715">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/3.jpg" alt=""><div class="inner-team element" id="element_1434449390787">
                                <h3 class=" element" id="element_1434449390036">Kate Metus</h3>
                                <small class="color-green">Project Manager</small>
                                <p class="element" id="element_1434449390809">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li><a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
</div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/2.jpg" alt=""><div class="inner-team element" id="element_1434449389995">
                                <h3 class=" element">Porta Gravida</h3>
                                <small class="color-green">VP of Operations</small>
                                <p class=" element">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li>
                                        <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                </ul>
</div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/4.jpg" alt=""><div class="inner-team element" id="element_1434449389984">
                                <h3 class=" element">Donec Elisson</h3>
                                <small class="color-green">Director, R &amp; D Talent</small>
                                <p class="element" id="element_1434449389974">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li>
                                        <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                            <i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                </ul>
</div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        

        
        <div class="container content our-location element" id="element_1434449391424">
            <div class="title-box-v2 element">
                <h2 class=" element">Contact <span class="color-green">Us</span>
</h2>
                <p class=" element" id="element_1434449390971">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>

            <div class="row margin-bottom-30 element" id="element_1434449391001">
                <div class="col-md-8 text-justify md-margin-bottom-20" style="height: auto;">
                    <p class=" element"><span class="dropcap dropcap-bg bg-color-dark">A</span>liquam non purus tempor, convallis lectus sit amet, eleifend metus. Maecenas non convallis felis. Suspendisse consequat ligula eget ipsum consectetur vehicula. Vivamus metus eros, condimentum id enim aliquam, feugiat pellentesque est. Proin justo sapien, suscipit in tincidunt non, sollicitudin sed arcu. Suspendisse mattis urna libero, quis congue justo viverra vitae. Etiam sed erat quis mi vulputate placerat. Nulla eget sapien imperdiet eros dignissim posuere. Donec rhoncus congue purus quis placerat. Vivamus vel est sed arcu ultrices feugiat eu sit amet nunc.</p>
                    <p class=" element">Mauris viverra tristique nunc, a tempus dui venenatis vel. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus mollis nisl in porta cursus. Nullam hendrerit scelerisque tortor nec feugiat. In hac habitasse platea dictumst.</p>
                    <p class=" element">Aenean iaculis risus ligula, interdum pellentesque ante sollicitudin at. Proin et placerat quam. Vivamus sagittis luctus ipsum, ac auctor nibh interdum malesuada. Ut ut eros nibh. Sed dignissim vehicula metus eget feugiat.</p>
<br><div class="row about-list-style element" id="element_1434449390991">
                        <div class="col-xs-6 about-list-style-in" style="height: auto;">
                            <ul class="list-unstyled">
<li>
<i class="fa fa-check color-green"></i> Donec id elit non mi porta gravida</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Responsive Bootstrap Template</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Nullam hendrerit scelerisque tortor nec feugiat</li>
                                <li>
<i class="fa fa-check color-green"></i> Sed dignissim vehicula metus eget feugiat</li>
                            </ul>
</div>
                        <div class="col-xs-6 about-list-style-in" style="height: auto;">
                            <ul class="list-unstyled">
<li>
<i class="fa fa-check color-green"></i> Donec id elit non mi porta gravida</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Responsive Bootstrap Template</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Nullam hendrerit scelerisque tortor nec feugiat</li>
                                <li>
<i class="fa fa-check color-green"></i> Sed dignissim vehicula metus eget feugiat</li>
                            </ul>
</div>
                    </div>

                </div>

                <div class="col-md-4" style="height: auto;">
                    
                    <div id="map" class="map margin-bottom-40 element"><p class="element"></p></div>
                    

                    
                    <h3 class=" element">Our Office Details</h3>
                    <ul class="list-unstyled who">
<li><a href="#"><i class="fa fa-home"></i>5B Streat, City 50987 New Town US</a></li>
                        <li><a href="#"><i class="fa fa-envelope"></i>info@example.com</a></li>
                        <li><a href="#"><i class="fa fa-phone"></i>1(222) 5x86 x97x</a></li>
                        <li><a href="#"><i class="fa fa-globe"></i>http://www.example.com</a></li>
                    </ul>

</div>
            </div>

            
            <div class="owl-carousel-style-v2 element" id="element_1434449391433">
                <div class="headline element"><h2 class=" element">Our Clients</h2></div>
                <module class="module module-pictures" data-mw-title="Picture Gallery" id="aboutusslider" template="owl-carousel" data-type="pictures"></module>
</div>
            

        </div>
        '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('113','2015-06-16 16:50:49','2015-06-16 16:50:49','1','1','aboutus','18','aboutus','


        <div class="container content element" id="element_1434473399648">
            <div class="title-box-v2 element">
                <h2 class=" element">About <span class="color-green">Us</span>
</h2>
                <p class=" element">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>

            
            <div class="shadow-wrapper margin-bottom-50 element" id="element_1434473399679">
<module class=" module module-pictures " data-mw-title="Picture Gallery" id="picsliderbig" data-type="pictures"></module>
</div>
            

            
            <div class="row element" id="element_1434473398689">
                <div class="col-md-8" style="height: auto;">
                    <div class="row element">
                        <div class="col-sm-4" style="height: auto;">
                            <img alt="" src="{SITE_URL}userfiles/templates/tarita/assets/img/main/6.jpg" class="img-responsive margin-bottom-20">
</div>
                        <div class="col-sm-8" style="height: auto;">
                            <p class=" element">Unify is an incredibly beautiful responsive Bootstrap Template for corporate and creative professionals. It works on all major web browsers, tablets and phone.</p>
                            <ul class="list-unstyled margin-bottom-20">
<li>
<i class="fa fa-check color-green"></i> Donec id elit non mi porta gravida</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Responsive Bootstrap Template</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                            </ul>
</div>
                    </div>

                    <blockquote class="hero-unify">
                        <p class=" element">Award winning digital agency. We bring a personal and effective approach to every project we work on, which is why. Unify is an incredibly beautiful responsive Bootstrap Template for corporate professionals.</p>
                        <small>CEO, Jack Bour</small>
                    </blockquote>
                </div>


                <div class="col-md-4" style="height: auto;">
                    <h3 class="heading-xs no-top-space element">Web Design <span class="pull-right">88%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 88%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="88" role="progressbar" class="progress-bar progress-bar-u element"><p class="element">
                        </p></div>
                    </div>

                    <h3 class="heading-xs no-top-space element">PHP/WordPress <span class="pull-right">76%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 76%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="76" role="progressbar" class="progress-bar progress-bar-u element"><p class="element">
                        </p></div>
                    </div>

                    <h3 class="heading-xs no-top-space element">HTML/CSS <span class="pull-right">97%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 97%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="97" role="progressbar" class="progress-bar progress-bar-u element"><p class="element">
                        </p></div>
                    </div>

                    <h3 class="heading-xs no-top-space element">Web Animation <span class="pull-right">68%</span>
</h3>
                    <div class="progress progress-u progress-xs element">
                        <div style="width: 68%" aria-valuemax="100" aria-valuemin="0" aria-valuenow="68" role="progressbar" class="progress-bar progress-bar-u element"><p class="element">
                        </p></div>
                    </div>
                </div>

            </div>
            
        </div>
        

        
<module class="module  module module-paralaxblock" id="paralaxblockaboutus1" template="team3" data-type="paralaxblock"></module><div class="container content element">
            <div class="title-box-v2 element">
                <h2 class=" element">Company <span class="color-green">life</span>
</h2>
                <p class=" element">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>

            <div class="row margin-bottom-40 element">
                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.3.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.3.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.3.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-2.3.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                
            </div>

            <div class="row element">
                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">

                        <div class="simple-block element">
                            <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.3.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                        </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-1.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <img class="img-responsive img-bordered" src="{SITE_URL}userfiles/templates/tarita/assets/img/job/high-rated-job-2.2.jpg" alt=""><p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                

                
                <div class="col-md-3 col-sm-6 md-margin-bottom-20" style="height: auto;">
                    <div class="simple-block element">
                        <div class="responsive-video element"><p class="element">
                            
                        </p></div>
                        <p class=" element">Pellentesque et erat ac massa cursus porttitor eget sed magna.</p>
                    </div>
                </div>
                
            </div>
        </div>

        

        
        <div class="parallax-team parallaxBg element">
            <div class="container content element">
                <div class="title-box-v2 element">
                    <h2 class=" element">Build Your <span class="color-green">Own</span> Talents</h2>
                    <p class=" element">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                </div>

                <div class="row element">
                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/1.jpg" alt=""><div class="inner-team element">
                                <h3 class=" element">Jack Anderson</h3>
                                <small class="color-green">CEO, Chief Officer</small>
                                <p class=" element">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li>
                                        <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                </ul>
</div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/3.jpg" alt=""><div class="inner-team element">
                                <h3 class=" element">Kate Metus</h3>
                                <small class="color-green">Project Manager</small>
                                <p class=" element">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li><a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                                    <li><a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                                    <li><a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
</div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/2.jpg" alt=""><div class="inner-team element">
                                <h3 class=" element">Porta Gravida</h3>
                                <small class="color-green">VP of Operations</small>
                                <p class=" element">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li>
                                        <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                </ul>
</div>
                        </div>
                    </div>
                    

                    
                    <div class="col-md-3 col-sm-6" style="height: auto;">
                        <div class="team-v2 element">
                            <img class="img-responsive" src="{SITE_URL}userfiles/templates/tarita/assets/img/team/4.jpg" alt=""><div class="inner-team element">
                                <h3 class=" element">Donec Elisson</h3>
                                <small class="color-green">Director, R &amp; D Talent</small>
                                <p class=" element">Donec id elit non mi porta gravida at eget metus. Fusce dapibus, justo sit amet risus etiam porta sem...</p>
                                <hr>
<ul class="list-inline team-social">
<li>
                                        <a data-placement="top" data-toggle="tooltip" class="fb tooltips" data-original-title="Facebook" href="#">
                                            <i class="fa fa-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="tw tooltips" data-original-title="Twitter" href="#">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a data-placement="top" data-toggle="tooltip" class="gp tooltips" data-original-title="Google plus" href="#">
                                            <i class="fa fa-google-plus"></i>
                                        </a>
                                    </li>
                                </ul>
</div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        

        
        <div class="container content our-location element" id="element_1434473400102">
            <div class="title-box-v2 element" id="element_1434473400080">
                <h2 class="element" id="element_1434473400019">Contact <span class="color-green">Us</span>
</h2>
                <p class="element" id="element_1434473400004">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
            </div>

            <div class="row margin-bottom-30 element" id="element_1434473399963">
                <div class="col-md-8 text-justify md-margin-bottom-20" style="height: auto;">
                    <p class="element" id="element_1434473400401"><span class="dropcap dropcap-bg bg-color-dark">A</span>liquam non purus tempor, convallis lectus sit amet, eleifend metus. Maecenas non convallis felis. Suspendisse consequat ligula eget ipsum consectetur vehicula. Vivamus metus eros, condimentum id enim aliquam, feugiat pellentesque est. Proin justo sapien, suscipit in tincidunt non, sollicitudin sed arcu. Suspendisse mattis urna libero, quis congue justo viverra vitae. Etiam sed erat quis mi vulputate placerat. Nulla eget sapien imperdiet eros dignissim posuere. Donec rhoncus congue purus quis placerat. Vivamus vel est sed arcu ultrices feugiat eu sit amet nunc.</p>
                    <p class="element">Mauris viverra tristique nunc, a tempus dui venenatis vel. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus mollis nisl in porta cursus. Nullam hendrerit scelerisque tortor nec feugiat. In hac habitasse platea dictumst.</p>
                    <p class=" element">Aenean iaculis risus ligula, interdum pellentesque ante sollicitudin at. Proin et placerat quam. Vivamus sagittis luctus ipsum, ac auctor nibh interdum malesuada. Ut ut eros nibh. Sed dignissim vehicula metus eget feugiat.</p>
<br><div class="row about-list-style element">
                        <div class="col-xs-6 about-list-style-in" style="height: auto;">
                            <ul class="list-unstyled">
<li>
<i class="fa fa-check color-green"></i> Donec id elit non mi porta gravida</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Responsive Bootstrap Template</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Nullam hendrerit scelerisque tortor nec feugiat</li>
                                <li>
<i class="fa fa-check color-green"></i> Sed dignissim vehicula metus eget feugiat</li>
                            </ul>
</div>
                        <div class="col-xs-6 about-list-style-in" style="height: auto;">
                            <ul class="list-unstyled">
<li>
<i class="fa fa-check color-green"></i> Donec id elit non mi porta gravida</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Responsive Bootstrap Template</li>
                                <li>
<i class="fa fa-check color-green"></i> Corporate and Creative</li>
                                <li>
<i class="fa fa-check color-green"></i> Nullam hendrerit scelerisque tortor nec feugiat</li>
                                <li>
<i class="fa fa-check color-green"></i> Sed dignissim vehicula metus eget feugiat</li>
                            </ul>
</div>
                    </div>

                </div>

                <div class="col-md-4" style="height: auto;">
                    
                    <div id="map" class="map margin-bottom-40 element">
<module class="module module-google-maps " data-mw-title="Google Maps" data-type="google_maps" id="google-maps-20150616165042"></module><p class="element"></p>
</div>
                    

                    
                    <h3 class=" element">Our Office Details</h3>
                    <ul class="list-unstyled who">
<li><a href="#"><i class="fa fa-home"></i>5B Streat, City 50987 New Town US</a></li>
                        <li><a href="#"><i class="fa fa-envelope"></i>info@example.com</a></li>
                        <li><a href="#"><i class="fa fa-phone"></i>1(222) 5x86 x97x</a></li>
                        <li><a href="#"><i class="fa fa-globe"></i>http://www.example.com</a></li>
                    </ul>

</div>
            </div>

            
            <div class="owl-carousel-style-v2 element">
                <div class="headline element"><h2 class=" element">Our Clients</h2></div>
                <module class=" module module-pictures " data-mw-title="Picture Gallery" id="aboutusslider" template="owl-carousel" data-type="pictures"></module>
</div>
            

        </div>
        '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('114','2015-06-16 17:18:46','2015-06-16 17:18:46','1','1','2colr22','22','2colr','
        
        <div class="container content element">
        <div class="row element" id="element_1434475073354">
        <div class="col-md-9" style="height: auto;">
            
            <div class="headline element" id="element_1434475080207"><h2 class=" element">Our Services</h2></div>
            <div class="row margin-bottom-20 element">
                <div class="col-md-4" style="height: auto;">
                    <module class=" module module-boxes " id="b1" data-type="boxes"></module>
</div>
                <div class="col-md-4" style="height: auto;">
                    <module class=" module module-boxes " id="b12" data-type="boxes"></module>
</div>
                <div class="col-md-4" style="height: auto;">
                    <module class=" module module-boxes " id="b13" data-type="boxes"></module>
</div>
            </div>

            

            
            <p class=" element" id="element_1434475074850">Unify is an <strong class="color-green">incredibly beautiful</strong> responsive Bootstrap Template for corporate and creative professionals. It works on all major web browsers. Award winning digital agency. We bring a personal and effective approach adipiscing elit approach to <strong class="color-green">every project</strong> we work on, which is why our clients love us and why they. Lorem sequat ipsum dolor lorem sit amet, consectetur adipiscing dolor elit.</p>
            <p class=" element" id="element_1434475073322">Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Lorem ipsum dolor sit amet, conse cteturse adipiscing elit magna consectetur and effective.</p>
            <br><blockquote class="hero-unify margin-bottom-40">
                <p class="element" id="element_1434475073287">Award winning digital agency. We bring a personal and effective consectetur and effective approach adipiscing elit approach to every project we work on, which is why our clients love us and why they.</p>
                <small>CEO, Jack Baur</small>
            </blockquote>
            

            
            <div class="owl-carousel-v1 owl-work-v1 margin-bottom-40 element">
                <div class="headline element">
<h2 class="pull-left element">Recent Works</h2>
                       </div>

                <module class=" module module-pictures " data-mw-title="Picture Gallery" template="inner" id="2cr22" data-type="pictures"></module>
</div>
            
        </div>


        <div class="col-md-3" style="height: auto;">
            
            <div class="margin-bottom-30 element" id="element_1434475074333">
                <div class="headline element"><h2 class=" element">About Us</h2></div>
                <p class=" element" id="element_1434475080158">Fusce condimentum eleifend enim a feugiat. Pellentesque viverra vehicula sem ut volutpat. Lorem ipsum dolor sit amet, conse cteturse adipiscing elit magna.</p>
                <ul class="list-unstyled">
<li>
<i class="fa fa-check color-green"></i> Consectetur adipiscing elit</li>
                    <li>
<i class="fa fa-check color-green"></i> Ipsum dolor sit amet</li>
                    <li>
<i class="fa fa-check color-green"></i> Personal and effective approach</li>
                    <li>
<i class="fa fa-check color-green"></i> Ut non libero magna sedot</li>
</ul>
</div>
<div class="posts margin-bottom-30 element" id="element_1434475074044">
                <module class="module  module module-posts" data-mw-title="Posts List" id="right22" data-type="posts"></module>
</div>


            
            <div class="who margin-bottom-30 element">
                <div class="headline element"><h2 class=" element">Contact Us</h2></div>
                <p class=" element">Vero facilis est etenim a feugiat cupiditate non quos etrerum facilis.</p>
                <ul class="list-unstyled">
<li><a href="#"><i class="fa fa-home"></i>5B amus ED554, New York, US</a></li>
                    <li><a href="#"><i class="fa fa-envelope"></i>infp@example.com</a></li>
                    <li><a href="#"><i class="fa fa-phone"></i>1(222) 5x86 x97x</a></li>
                    <li><a href="#"><i class="fa fa-globe"></i>http://www.example.com</a></li>
                </ul>
</div>
        </div>

        </div>


        
        <div id="clients-flexslider" class="flexslider home clients element">
            <div class="headline element"><h3 class=" element">Our Clients</h3></div>
            <module class=" module module-pictures " data-mw-title="Picture Gallery" template="owl-carousel" id="clients22" data-type="pictures"></module>
</div>

        
        </div>
    '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('115','2015-06-16 17:18:46','2015-06-16 17:18:46','1','1','awd2right22','22','aweright22','<h2>Posts without images</h2>'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('116','2015-06-24 09:22:08','2015-06-24 09:22:08','1','1','content','25','content_body','
                    <p class="element" id="element_1435136139316"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('117','2015-06-24 09:23:15','2015-06-24 09:23:15','1','1','content','26','content_body','
                    <p class="element" id="element_1435137761258"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('118','2015-06-24 09:24:13','2015-06-24 09:24:13','1','1','content','27','content_body','
                    <p class="element" id="element_1435137843215"><span style="color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans; font-size: 11px; line-height: 14px; text-align: justify;">"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</span></p>
                  '); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields (id,updated_at,created_at,created_by,edited_by,rel_type,rel_id,field,value) VALUES('121','2015-06-30 18:31:46','2015-06-30 18:31:46','1','1','content','6','content_body','
<div><br></div>
<div>
<table width="580px"><tbody><tr><td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</td></tr></tbody></table>
<table width="580px"><tbody><tr><td>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</td></tr></tbody></table>
</div>
'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('1','2015-05-11 19:07:27','2015-05-11 19:07:27','1','1','7fac05793256c895acd4f12fb9da25dca8acf063','content','5','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/11_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('2','2015-05-23 15:53:17','2015-05-23 15:53:17','1','1','ee0d1ac989e8b720e18295cbe939f86d74fd3c30','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/11_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('3','2015-05-23 15:53:17','2015-05-23 15:53:17','1','1','ee0d1ac989e8b720e18295cbe939f86d74fd3c30','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/12_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('4','2015-05-23 15:53:17','2015-05-23 15:53:17','1','1','ee0d1ac989e8b720e18295cbe939f86d74fd3c30','content','9','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/img18_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('5','2015-05-24 09:07:29','2015-05-24 09:07:29','2','2','4591fb92bb8757e6fe8daf3f70d2945ab3876aba','modules','awd1','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/photo_1421757295538_9c80958e75b0.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('6','2015-05-24 09:07:32','2015-05-24 09:07:32','2','2','4591fb92bb8757e6fe8daf3f70d2945ab3876aba','modules','awd1','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/photo_1428604467652_115d9d71a7f1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('7','2015-05-24 09:36:35','2015-05-24 09:36:35','2','2','75b5feb0e109cc48cca3ff3fede9df476c690965','modules','awd1','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/eda0fb7c.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('8','2015-05-24 13:14:37','2015-05-24 13:14:37','1','1','8c228a06922f3ceaa648a51224e0d034556737b6','modules','picturessmall3','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/11_6.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('9','2015-05-24 13:14:37','2015-05-24 13:14:37','1','1','8c228a06922f3ceaa648a51224e0d034556737b6','modules','picturessmall3','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/12_6.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('10','2015-05-24 13:14:49','2015-05-24 13:14:49','1','1','8c228a06922f3ceaa648a51224e0d034556737b6','modules','picturessmall3','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/img18_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('11','2015-06-14 12:06:53','2015-06-14 12:06:53','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('12','2015-06-14 12:06:53','2015-06-14 12:06:53','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('13','2015-06-14 12:06:53','2015-06-14 12:06:53','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('14','2015-06-14 12:06:54','2015-06-14 12:06:54','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('15','2015-06-14 12:06:55','2015-06-14 12:06:55','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('16','2015-06-14 12:06:55','2015-06-14 12:06:55','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/6.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('17','2015-06-14 12:06:56','2015-06-14 12:06:56','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/7.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('18','2015-06-14 12:06:56','2015-06-14 12:06:56','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/8.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('19','2015-06-14 12:06:57','2015-06-14 12:06:57','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/9.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('20','2015-06-14 12:06:57','2015-06-14 12:06:57','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/10.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('21','2015-06-14 12:06:58','2015-06-14 12:06:58','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/11_7.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('22','2015-06-14 12:06:58','2015-06-14 12:06:58','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/12_7.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('23','2015-06-14 12:21:52','2015-06-14 12:21:52','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('24','2015-06-14 12:21:52','2015-06-14 12:21:52','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/2_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('25','2015-06-14 12:21:52','2015-06-14 12:21:52','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/3_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('26','2015-06-14 12:21:53','2015-06-14 12:21:53','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('27','2015-06-14 12:21:53','2015-06-14 12:21:53','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/5_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('28','2015-06-14 12:21:53','2015-06-14 12:21:53','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/6_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('29','2015-06-14 12:21:54','2015-06-14 12:21:54','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/7_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('30','2015-06-14 12:21:54','2015-06-14 12:21:54','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/8_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('31','2015-06-14 12:21:54','2015-06-14 12:21:54','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/9_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('32','2015-06-14 12:21:55','2015-06-14 12:21:55','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/10_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('33','2015-06-14 12:21:55','2015-06-14 12:21:55','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/11_8.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('34','2015-06-14 12:21:55','2015-06-14 12:21:55','1','1','1e28c0fe9867057d4ebd49ab79cf0da60d9b802c','modules','images15','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/12_8.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('35','2015-06-14 13:38:44','2015-06-14 13:38:44','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','module-pictures-index2-689369199','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/21.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('36','2015-06-14 13:38:44','2015-06-14 13:38:44','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','module-pictures-index2-689369199','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/23.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('37','2015-06-14 13:38:45','2015-06-14 13:38:45','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','module-pictures-index2-689369199','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/24.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('40','2015-06-14 13:58:24','2015-06-14 13:58:24','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','bigslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/3_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('41','2015-06-14 13:58:24','2015-06-14 13:58:24','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','bigslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('42','2015-06-14 14:26:01','2015-06-14 14:26:01','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','bigslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/7_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('43','2015-06-14 16:00:57','2015-06-14 16:00:57','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','slider116','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('44','2015-06-14 16:00:57','2015-06-14 16:00:57','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','slider116','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/2_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('45','2015-06-14 16:00:58','2015-06-14 16:00:58','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','slider116','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/3_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('46','2015-06-14 16:00:58','2015-06-14 16:00:58','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','slider116','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('47','2015-06-14 16:00:58','2015-06-14 16:00:58','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','slider116','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/5_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('48','2015-06-14 16:00:58','2015-06-14 16:00:58','1','1','fe5d0e833b8ccbf9bba2a4b14c2d4614409f86e4','modules','slider116','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/6_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('49','2015-06-15 20:46:27','2015-06-15 20:46:27','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/austrian_airlines.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('50','2015-06-15 20:46:27','2015-06-15 20:46:27','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/baderbrau.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('51','2015-06-15 20:46:28','2015-06-15 20:46:28','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/bellfield.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('52','2015-06-15 20:46:28','2015-06-15 20:46:28','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/clarks.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('53','2015-06-15 20:46:28','2015-06-15 20:46:28','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/corepreserves.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('54','2015-06-15 20:46:29','2015-06-15 20:46:29','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/co_wheels.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('55','2015-06-15 20:46:29','2015-06-15 20:46:29','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/cropped.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('56','2015-06-15 20:46:29','2015-06-15 20:46:29','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/district_karaoke.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('57','2015-06-15 20:46:30','2015-06-15 20:46:30','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/dragnfly.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('58','2015-06-15 20:46:30','2015-06-15 20:46:30','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/ea_canada.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('59','2015-06-15 20:46:30','2015-06-15 20:46:30','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/emirates.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('60','2015-06-15 20:46:31','2015-06-15 20:46:31','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/fddw.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('61','2015-06-15 20:46:31','2015-06-15 20:46:31','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/finals.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('62','2015-06-15 20:46:31','2015-06-15 20:46:31','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/fred_perry.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('63','2015-06-15 20:46:31','2015-06-15 20:46:31','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/general_electric.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('64','2015-06-15 20:46:32','2015-06-15 20:46:32','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/getapp.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('65','2015-06-15 20:46:32','2015-06-15 20:46:32','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/getaround.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('66','2015-06-15 20:46:32','2015-06-15 20:46:32','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/grifting_tree.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('67','2015-06-15 20:46:33','2015-06-15 20:46:33','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/hermes.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('68','2015-06-15 20:46:33','2015-06-15 20:46:33','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/hotiron.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('69','2015-06-15 20:46:33','2015-06-15 20:46:33','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/inspiring.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('70','2015-06-15 20:46:34','2015-06-15 20:46:34','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/jaguar.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('71','2015-06-15 20:46:34','2015-06-15 20:46:34','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/marianos.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('72','2015-06-15 20:46:34','2015-06-15 20:46:34','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/much_more.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('73','2015-06-15 20:46:34','2015-06-15 20:46:34','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/national_geographic.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('74','2015-06-15 20:46:35','2015-06-15 20:46:35','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/qantas_airways.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('75','2015-06-15 20:46:35','2015-06-15 20:46:35','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/starbucks.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('76','2015-06-15 20:46:35','2015-06-15 20:46:35','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','aboutusslider','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/ucweb.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('77','2015-06-15 20:52:57','2015-06-15 20:52:57','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','picsliderbig','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('78','2015-06-15 20:52:58','2015-06-15 20:52:58','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','picsliderbig','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/2_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('79','2015-06-15 20:52:58','2015-06-15 20:52:58','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','picsliderbig','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/3_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('80','2015-06-15 20:52:58','2015-06-15 20:52:58','1','1','45e3595681255cd6258fec1fb66858f67f28924b','modules','picsliderbig','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('81','2015-06-16 15:40:16','2015-06-16 15:40:16','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','bigslider1','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('82','2015-06-16 15:40:17','2015-06-16 15:40:17','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','bigslider1','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/3_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('83','2015-06-16 15:40:17','2015-06-16 15:40:17','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','bigslider1','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4_6.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('84','2015-06-16 15:55:46','2015-06-16 15:55:46','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','bigslider215','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/7_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('85','2015-06-16 15:55:46','2015-06-16 15:55:46','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','bigslider215','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/8_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('86','2015-06-16 15:55:46','2015-06-16 15:55:46','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','bigslider215','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/9_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('87','2015-06-16 17:09:43','2015-06-16 17:09:43','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('88','2015-06-16 17:09:43','2015-06-16 17:09:43','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('89','2015-06-16 17:09:43','2015-06-16 17:09:43','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('90','2015-06-16 17:09:43','2015-06-16 17:09:43','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('91','2015-06-16 17:20:21','2015-06-16 17:20:21','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr23','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.3_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('92','2015-06-16 17:20:21','2015-06-16 17:20:21','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr23','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('93','2015-06-16 17:20:21','2015-06-16 17:20:21','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr23','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('94','2015-06-16 17:20:21','2015-06-16 17:20:21','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr23','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('95','2015-06-16 17:20:22','2015-06-16 17:20:22','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','2cr23','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('101','2015-06-16 17:20:35','2015-06-16 17:20:35','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','1','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/6.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('102','2015-06-16 17:21:09','2015-06-16 17:21:09','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','2','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/shell_Copy.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('103','2015-06-16 17:21:28','2015-06-16 17:21:28','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','3','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/austrian_airlines_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('104','2015-06-16 17:21:28','2015-06-16 17:21:28','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','4','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/baderbrau_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('105','2015-06-16 17:21:28','2015-06-16 17:21:28','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','0','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/bellfield_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('106','2015-06-16 17:21:28','2015-06-16 17:21:28','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','5','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/clarks_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('107','2015-06-16 17:21:29','2015-06-16 17:21:29','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','7','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/corepreserves_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('108','2015-06-16 17:21:29','2015-06-16 17:21:29','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','6','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/co_wheels_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('109','2015-06-16 17:21:29','2015-06-16 17:21:29','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','8','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/cropped_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('110','2015-06-16 17:21:30','2015-06-16 17:21:30','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','9','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/district_karaoke_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('111','2015-06-16 17:21:30','2015-06-16 17:21:30','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','10','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/dragnfly_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('112','2015-06-16 17:21:30','2015-06-16 17:21:30','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','11','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/ea_canada_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('113','2015-06-16 17:21:30','2015-06-16 17:21:30','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients23','picture','12','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/emirates_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('114','2015-06-16 17:21:45','2015-06-16 17:21:45','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/austrian_airlines_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('115','2015-06-16 17:21:46','2015-06-16 17:21:46','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/baderbrau_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('116','2015-06-16 17:21:46','2015-06-16 17:21:46','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/bellfield_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('117','2015-06-16 17:21:48','2015-06-16 17:21:48','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/clarks_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('118','2015-06-16 17:21:48','2015-06-16 17:21:48','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/corepreserves_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('119','2015-06-16 17:21:49','2015-06-16 17:21:49','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/co_wheels_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('120','2015-06-16 17:21:50','2015-06-16 17:21:50','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/cropped_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('121','2015-06-16 17:21:51','2015-06-16 17:21:51','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/district_karaoke_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('122','2015-06-16 17:21:52','2015-06-16 17:21:52','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/dragnfly_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('123','2015-06-16 17:21:53','2015-06-16 17:21:53','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/ea_canada_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('124','2015-06-16 17:21:54','2015-06-16 17:21:54','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/emirates_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('125','2015-06-16 17:21:54','2015-06-16 17:21:54','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/fddw_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('126','2015-06-16 17:21:55','2015-06-16 17:21:55','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/finals_2.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('127','2015-06-16 17:21:55','2015-06-16 17:21:55','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/fred_perry_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('128','2015-06-16 17:21:55','2015-06-16 17:21:55','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/general_electric_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('129','2015-06-16 17:21:55','2015-06-16 17:21:55','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/getapp_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('130','2015-06-16 17:21:56','2015-06-16 17:21:56','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/getaround_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('131','2015-06-16 17:21:56','2015-06-16 17:21:56','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/grifting_tree_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('132','2015-06-16 17:21:57','2015-06-16 17:21:57','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/hermes_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('133','2015-06-16 17:21:57','2015-06-16 17:21:57','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/hotiron_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('134','2015-06-16 17:21:58','2015-06-16 17:21:58','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/inspiring_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('135','2015-06-16 17:21:59','2015-06-16 17:21:59','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/jaguar_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('136','2015-06-16 17:22:00','2015-06-16 17:22:00','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/marianos_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('137','2015-06-16 17:22:01','2015-06-16 17:22:01','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/much_more_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('138','2015-06-16 17:22:03','2015-06-16 17:22:03','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/national_geographic_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('139','2015-06-16 17:22:03','2015-06-16 17:22:03','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/qantas_airways_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('140','2015-06-16 17:22:04','2015-06-16 17:22:04','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/starbucks_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('141','2015-06-16 17:22:05','2015-06-16 17:22:05','1','1','abfcb32b947729b406edf3f82103df1e313e4cf9','modules','clients22','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/ucweb_1.png'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('142','2015-06-23 09:52:59','2015-06-23 09:52:59','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','24','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/flag_world_russia.gif'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('143','2015-06-23 09:52:59','2015-06-23 09:52:59','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','24','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/price_logo.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('146','2015-06-23 09:59:24','2015-06-23 09:59:24','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','124','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.1_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('147','2015-06-23 09:59:24','2015-06-23 09:59:24','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','124','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.2_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('148','2015-06-23 11:30:00','2015-06-23 11:30:00','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','224','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.1_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('149','2015-06-23 11:30:00','2015-06-23 11:30:00','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','224','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.3_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('150','2015-06-23 11:30:01','2015-06-23 11:30:01','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','224','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.1_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('151','2015-06-23 11:30:27','2015-06-23 11:30:27','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','224','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.3_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('152','2015-06-23 11:30:28','2015-06-23 11:30:28','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','224','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.2_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('153','2015-06-23 11:30:28','2015-06-23 11:30:28','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','224','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.3_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('154','2015-06-23 11:30:35','2015-06-23 11:30:35','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','124','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.2_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('155','2015-06-23 11:30:35','2015-06-23 11:30:35','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','124','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.2_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('156','2015-06-23 11:32:51','2015-06-23 11:32:51','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('157','2015-06-23 11:32:51','2015-06-23 11:32:51','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.1_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('158','2015-06-23 11:32:51','2015-06-23 11:32:51','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.2_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('161','2015-06-23 11:32:52','2015-06-23 11:32:52','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.1_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('162','2015-06-23 11:32:53','2015-06-23 11:32:53','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.2_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('164','2015-06-23 11:32:53','2015-06-23 11:32:53','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.1_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('165','2015-06-23 11:32:54','2015-06-23 11:32:54','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('166','2015-06-23 11:32:54','2015-06-23 11:32:54','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('167','2015-06-23 11:32:54','2015-06-23 11:32:54','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_4.1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('168','2015-06-23 11:32:54','2015-06-23 11:32:54','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_4.2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('169','2015-06-23 11:32:55','2015-06-23 11:32:55','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_4.3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('170','2015-06-23 11:32:55','2015-06-23 11:32:55','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','324','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_5.1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('171','2015-06-23 11:33:24','2015-06-23 11:33:24','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('172','2015-06-23 11:33:24','2015-06-23 11:33:24','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.1_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('173','2015-06-23 11:33:25','2015-06-23 11:33:25','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.2_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('174','2015-06-23 11:33:25','2015-06-23 11:33:25','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1.3_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('175','2015-06-23 11:33:25','2015-06-23 11:33:25','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_1_2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('176','2015-06-23 11:33:25','2015-06-23 11:33:25','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.1_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('177','2015-06-23 11:33:26','2015-06-23 11:33:26','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.2_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('178','2015-06-23 11:33:26','2015-06-23 11:33:26','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_2.3_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('179','2015-06-23 11:33:26','2015-06-23 11:33:26','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.1_3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('180','2015-06-23 11:33:26','2015-06-23 11:33:26','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.2_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('181','2015-06-23 11:33:27','2015-06-23 11:33:27','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_3.3_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('182','2015-06-23 11:33:27','2015-06-23 11:33:27','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_4.1_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('183','2015-06-23 11:33:27','2015-06-23 11:33:27','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_4.2_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('184','2015-06-23 11:33:28','2015-06-23 11:33:28','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_4.3_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('185','2015-06-23 11:33:28','2015-06-23 11:33:28','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_5.1_1.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('186','2015-06-23 11:33:28','2015-06-23 11:33:28','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_5.2.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('187','2015-06-23 11:33:28','2015-06-23 11:33:28','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/high_rated_job_5.3.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('188','2015-06-23 11:33:29','2015-06-23 11:33:29','1','1','00403a28d8dcbf6d3957aff56e9458cb14aca658','content','424','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/slider.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('189','2015-06-24 09:21:07','2015-06-24 09:21:07','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','content','25','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/product_5.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('190','2015-06-24 09:23:01','2015-06-24 09:23:01','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','content','26','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/product_10.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('191','2015-06-24 09:23:50','2015-06-24 09:23:50','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','content','27','picture','9999999','','','','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/product_4.jpg'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media (id,updated_at,created_at,created_by,edited_by,session_id,rel_type,rel_id,media_type,position,title,description,embed_code,filename) VALUES('193','2015-06-30 19:35:19','2015-06-30 19:35:19','1','1','9635714543e02e01bb94fe2da771b201a62dab6d','content','4','picture','9999999','','','','{SITE_URL}userfiles/media/digitaldreamer-microweber-com/uploaded/13.jpg'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('1','module','contact-form','0','name','Name','name','2015-05-10 13:22:43','2015-05-10 13:22:43','1','1','7ce3a1070602439bd6824143248961e48e064234','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('2','module','contact-form','1','email','Email','email','2015-05-10 13:22:43','2015-05-10 13:22:43','1','1','7ce3a1070602439bd6824143248961e48e064234','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('3','module','contact-form','2','message','Message','message','2015-05-10 13:22:43','2015-05-10 13:22:43','1','1','7ce3a1070602439bd6824143248961e48e064234','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('4','content','1','','price','price','price','2015-05-10 13:29:50','2015-05-10 13:29:50','1','1','7ce3a1070602439bd6824143248961e48e064234','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('5','content','25','','price','price','price','2015-06-24 08:55:46','2015-06-24 08:55:36','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('6','content','26','','price','price','price','2015-06-24 09:22:55','2015-06-24 09:22:38','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('7','content','27','','price','price','price','2015-06-24 09:23:41','2015-06-24 09:23:36','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('8','module','shipping-info-module-shop-shipping-gateways-country557478767','0','address','Address','address','2015-06-24 12:21:12','2015-06-24 12:21:12','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('9','module','shipping-info-module-shop-shipping-gateways-country557478767558aa0b88923a','0','address','Address','address','2015-06-24 12:21:12','2015-06-24 12:21:12','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('10','module','shipping-info-module-shop-shipping-gateways-country557478767558aa0b891324','0','address','Address','address','2015-06-24 12:21:12','2015-06-24 12:21:12','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('11','module','shipping-info-module-shop-shipping-gateways-country557478767558aa0b899bde','0','address','Address','address','2015-06-24 12:21:12','2015-06-24 12:21:12','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('12','module','shipping-info-module-shop-shipping-gateways-country557478767558aa0b8a5379','0','address','Address','address','2015-06-24 12:21:12','2015-06-24 12:21:12','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields (id,rel_type,rel_id,position,type,name,name_key,updated_at,created_at,created_by,edited_by,session_id,options,is_active,required,copy_of_field) VALUES('13','module','shipping-info-module-shop-shipping-gateways-country557478767558aa0b8b0b13','0','address','Address','address','2015-06-24 12:21:12','2015-06-24 12:21:12','1','1','df4332150f289922920c6d4be5214cfc19de3ba9','','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('1','4','0','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('2','5','15','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('3','6','20','0'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields_values (id,custom_field_id,value,position) VALUES('4','7','20','0'); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('1','header_menu','menu','','','','','2015-05-10 13:19:29','2015-05-10 13:19:29','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('2','','menu_item','1','1','','0','2015-05-10 13:19:29','2015-05-10 13:19:29','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('3','footer_menu','menu','','','','','2015-05-10 13:19:29','2015-05-10 13:19:29','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('5','topmenu','menu','','','','','2015-05-10 13:19:56','2015-05-10 13:19:56','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('6','footernemu','menu','','','','','2015-05-10 13:19:57','2015-05-10 13:19:57','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('7','footernemu','menu','','','','','2015-05-10 13:19:57','2015-05-10 13:19:57','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('9','','menu_item','21','2','','4','2015-05-10 13:24:04','2015-05-10 13:24:04','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('10','','menu_item','3','2','','999999','2015-05-10 13:24:04','2015-05-10 13:24:04','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('12','','menu_item','6','2','','5','2015-05-10 13:42:33','2015-05-10 13:42:33','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('13','','menu_item','6','1','','0','2015-05-10 13:42:36','2015-05-10 13:42:36','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('14','Tarita Blog version 1','menu_item','23','3','','11','2015-06-05 21:47:12','2015-05-10 14:40:00','1','','{SITE_URL}blog'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('15','','menu_item','3','3','','999999','2015-05-10 14:40:00','2015-05-10 14:40:00','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('16','Tarita Blog version 3','menu_item','23','8','','13','2015-06-23 13:55:14','2015-05-11 19:18:28','1','','{SITE_URL}tarita-blog-version-3'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('17','Tarita Blog version 2','menu_item','23','7','','12','2015-06-23 13:55:06','2015-05-11 19:19:33','1','','{SITE_URL}tarita-blog-version-2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('20','Services','menu_item','21','10','','5','2015-06-05 21:45:11','2015-05-24 08:58:32','1','','{SITE_URL}services-layout2'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('21','Pages','menu_item','1','','','3','2015-06-18 11:20:43','2015-06-05 21:43:58','','','#'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('22','Custom Modules','menu_item','1','','','18','2015-06-05 21:45:39','2015-06-05 21:45:39','','','#'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('23','Blog layout','menu_item','21','','','10','2015-06-05 21:47:24','2015-06-05 21:47:24','','','#'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('24','','menu_item','22','12','','19','2015-06-05 21:49:41','2015-06-05 21:49:41','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('25','','menu_item','22','13','','20','2015-06-05 21:50:16','2015-06-05 21:50:16','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('26','','menu_item','22','14','','21','2015-06-10 21:19:29','2015-06-10 21:19:29','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('27','','menu_item','2','15','','1','2015-06-14 15:48:01','2015-06-14 15:48:01','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('28','','menu_item','2','16','','2','2015-06-14 15:53:05','2015-06-14 15:53:05','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('29','','menu_item','22','17','','22','2015-06-15 20:21:10','2015-06-15 20:21:10','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('30','','menu_item','21','18','','9','2015-06-15 20:43:48','2015-06-15 20:43:48','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('31','','menu_item','6','9','','3','2015-06-16 10:49:45','2015-06-16 10:49:45','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('32','','menu_item','6','10','','4','2015-06-16 10:49:56','2015-06-16 10:49:56','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('33','','menu_item','6','13','','6','2015-06-16 10:50:06','2015-06-16 10:50:06','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('34','','menu_item','6','15','','1','2015-06-16 10:50:13','2015-06-16 10:50:13','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('35','','menu_item','6','16','','2','2015-06-16 10:50:47','2015-06-16 10:50:47','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('36','Sidebar left','menu_item','37','19','','7','2015-06-16 16:42:53','2015-06-16 16:40:20','1','','{SITE_URL}shop'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('37','Shop','menu_item','21','','','6','2015-06-16 16:42:00','2015-06-16 16:42:00','','','#'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('38','','menu_item','37','20','','8','2015-06-16 16:43:31','2015-06-16 16:43:31','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('40','Layout','menu_item','21','','','14','2015-06-16 16:56:30','2015-06-16 16:56:30','','','#'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('41','','menu_item','40','22','','15','2015-06-16 17:02:18','2015-06-16 17:02:18','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('42','','menu_item','40','23','','16','2015-06-16 17:03:08','2015-06-16 17:03:08','1','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus (id,title,item_type,parent_id,content_id,categories_id,position,updated_at,created_at,is_active,description,url) VALUES('43','','menu_item','21','24','','17','2015-06-23 09:43:57','2015-06-23 09:43:57','1','',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('1','2015-06-30 19:16:40','2015-05-10 13:19:29','current_template','tarita','','','','template','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('2','2015-05-10 13:19:29','2015-05-10 13:19:29','website_title','Microweber','','','','website','','','','','','1'); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('3','2015-05-10 13:19:29','2015-05-10 13:19:29','enable_comments','y','','','','comments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('4','2015-05-10 13:19:29','2015-05-10 13:19:29','shipping_gw_shop/shipping/gateways/country','y','','','','shipping','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('5','2015-05-10 13:19:29','2015-05-10 13:19:29','payment_gw_shop/payments/gateways/paypal','1','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('6','2015-05-10 13:19:29','2015-05-10 13:19:29','currency','USD','','','','payments','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('7','2015-05-10 13:25:13','2015-05-10 13:25:13','logoimage','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/taritalogo.png','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('8','2015-05-10 13:25:23','2015-05-10 13:25:13','size','150','','','','logo','','','','','logo',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('9','2015-05-10 13:42:16','2015-05-10 13:42:16','facebook_enabled','y','','','','social-links-20150510134207','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('10','2015-05-10 13:42:17','2015-05-10 13:42:17','twitter_enabled','y','','','','social-links-20150510134207','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('11','2015-05-10 13:42:18','2015-05-10 13:42:18','googleplus_enabled','y','','','','social-links-20150510134207','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('12','2015-05-10 13:42:19','2015-05-10 13:42:19','pinterest_enabled','y','','','','social-links-20150510134207','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('13','2015-05-10 13:42:20','2015-05-10 13:42:20','youtube_enabled','y','','','','social-links-20150510134207','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('14','2015-05-10 13:42:20','2015-05-10 13:42:20','linkedin_enabled','y','','','','social-links-20150510134207','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('15','2015-05-10 14:28:08','2015-05-10 13:46:13','slidescount','5','','','','slider1','','','','','predefinedslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('16','2015-05-10 14:36:12','2015-05-10 13:59:31','bgpic','','','','','slider1','','','','','predefinedslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('17','2015-05-10 14:25:57','2015-05-10 14:25:57','slidescount','5','','','','predefinedslider-20150510142552','','','','','predefinedslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('18','2015-05-24 12:00:23','2015-05-10 14:41:01','settings','{"0":{"primaryText":"Tarita Template / Theme","secondaryText":"Awesome Template for Microweber CMS. 100% Mobile Ready","url":"","skin":"backgrounded","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/photo_1421757295538_9c80958e75b0.jpg"},"1":{"primaryText":"Tarita Theme It&rsquo;s Just for You!","secondaryText":"Clean and Fully Responsive Template.","url":"","skin":"backgrounded","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/photo_1425136738262_212551713a58.jpg,{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/photo_1428604467652_115d9d71a7f1.jpg"}}','','','','module-magicslider-86389666','','','','','magicslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('19','2015-05-10 15:08:14','2015-05-10 15:08:14','embed_url','https://vimeo.com/47911018','','','','mwemodule-1431270479608','','','','','video',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('20','2015-05-10 15:12:18','2015-05-10 15:09:55','width','960','','','','mwemodule-1431270479608','','','','','video',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('21','2015-05-10 15:12:24','2015-05-10 15:10:00','height','540','','','','mwemodule-1431270479608','','','','','video',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('22','2015-05-11 18:38:53','2015-05-10 15:19:40','data-show','thumbnail, title, description, read_more, created_at','','','','features3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('23','2015-05-11 18:14:09','2015-05-10 15:19:46','data-character-limit','300','','','','features3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('24','2015-05-24 11:49:20','2015-05-11 07:14:59','data-template','blog_simple_default.php','','','','features3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('25','2015-05-11 19:48:18','2015-05-11 19:47:49','taritaColor','red','','','','tarita','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('26','2015-05-11 20:07:57','2015-05-11 20:00:15','color','purple','','','','settings/template','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('27','2015-06-17 15:22:06','2015-05-11 20:08:56','color','default','','','','tarita','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('28','2015-05-23 15:59:23','2015-05-11 20:28:00','theme','light','','','','tarita','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('29','2015-05-23 15:52:59','2015-05-23 15:52:59','data-use-from-post','y','','','','9','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('30','2015-05-23 15:53:24','2015-05-23 15:53:20','data-template','slider.php','','','','9','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('31','2015-05-23 15:53:32','2015-05-23 15:53:32','data-template','blue.php','','','','box2','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('32','2015-05-23 15:53:35','2015-05-23 15:53:35','data-template','dark.php','','','','module-boxes-services-257392932','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('33','2015-05-23 15:53:38','2015-05-23 15:53:38','data-template','darkblue.php','','','','box4','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('34','2015-05-23 15:53:42','2015-05-23 15:53:42','data-template','grey.php','','','','box5','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('35','2015-05-23 15:53:57','2015-05-23 15:53:55','data-template','purple.php','','','','box6','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('36','2015-05-23 15:54:03','2015-05-23 15:54:03','data-template','red.php','','','','module-boxes-services-2573929325560a246e5ab3','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('37','2015-05-23 15:54:06','2015-05-23 15:54:06','data-template','yellow.php','','','','box8','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('38','2015-05-23 15:54:30','2015-05-23 15:54:30','color','grey','','','','panel1','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('39','2015-05-23 15:54:35','2015-05-23 15:54:35','color','aqua','','','','panel2','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('40','2015-05-24 08:10:10','2015-05-23 15:54:40','color','success','','','','panel3','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('41','2015-05-24 11:21:59','2015-05-23 15:57:01','data-limit','999','','','','features3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('42','2015-05-24 08:41:03','2015-05-24 08:08:53','data-template','default','','','','box1','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('43','2015-05-24 11:21:24','2015-05-24 08:43:40','data-template','blog_simple_default.php','','','','feat27','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('44','2015-05-24 09:26:54','2015-05-24 09:26:54','data-template','normalview.php','','','','features10','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('45','2015-05-24 09:36:54','2015-05-24 09:36:52','data-use-from-post','','','','','awd1','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('46','2015-05-24 11:58:21','2015-05-24 09:48:27','data-template','slider.php','','','','awd1','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('47','2015-05-24 11:21:08','2015-05-24 11:21:01','data-show','thumbnail, title, description, read_more, created_at','','','','feat27','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('48','2015-05-24 11:22:39','2015-05-24 11:22:39','data-page-id','3','','','','sidebar3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('49','2015-05-24 11:22:46','2015-05-24 11:22:46','data-category-id','related','','','','sidebar3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('50','2015-06-16 15:45:04','2015-05-24 11:42:10','data-template','sidebar1.php','','','','sidebar3','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('51','2015-05-24 12:32:31','2015-05-24 12:32:31','data-template','resentposts.php','','','','1','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('52','2015-05-24 12:37:30','2015-05-24 12:37:30','data-template','resentposts.php','','','','services10','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('53','2015-05-24 12:58:47','2015-05-24 12:58:29','data-template','featured.php','','','','one7','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('54','2015-05-24 13:00:00','2015-05-24 12:59:57','data-use-from-post','','','','','picturessmall7','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('55','2015-05-24 13:02:02','2015-05-24 13:00:27','search_string','@Microweber','','','','twitter_feed7','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('56','2015-05-24 13:01:42','2015-05-24 13:01:42','facebook_enabled','y','','','','mwemodule-1432472491607','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('57','2015-05-24 13:01:43','2015-05-24 13:01:43','twitter_enabled','y','','','','mwemodule-1432472491607','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('58','2015-05-24 13:01:44','2015-05-24 13:01:44','googleplus_enabled','y','','','','mwemodule-1432472491607','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('59','2015-05-24 13:01:44','2015-05-24 13:01:44','pinterest_enabled','y','','','','mwemodule-1432472491607','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('60','2015-05-24 13:01:45','2015-05-24 13:01:45','youtube_enabled','y','','','','mwemodule-1432472491607','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('61','2015-05-24 13:01:47','2015-05-24 13:01:45','linkedin_enabled','','','','','mwemodule-1432472491607','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('62','2015-05-24 13:05:08','2015-05-24 13:04:57','number_of_items','','','','','twitter_feed7','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('63','2015-05-24 13:06:41','2015-05-24 13:06:41','facebook_enabled','y','','','','mwemodule-1432472790496','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('64','2015-05-24 13:06:41','2015-05-24 13:06:41','twitter_enabled','y','','','','mwemodule-1432472790496','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('65','2015-05-24 13:06:41','2015-05-24 13:06:41','googleplus_enabled','y','','','','mwemodule-1432472790496','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('66','2015-05-24 13:06:42','2015-05-24 13:06:42','pinterest_enabled','y','','','','mwemodule-1432472790496','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('67','2015-05-24 13:06:43','2015-05-24 13:06:43','youtube_enabled','y','','','','mwemodule-1432472790496','','','','','social_links',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('68','2015-05-24 13:14:08','2015-05-24 13:14:08','search_string','@Microweber','','','','twitter_feed3','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('69','2015-05-24 13:14:43','2015-05-24 13:14:41','data-use-from-post','','','','','picturessmall3','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('70','2015-05-24 13:19:42','2015-05-24 13:19:42','data-template','darkblue.php','','','','box210','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('71','2015-05-24 13:19:48','2015-05-24 13:19:48','data-template','red.php','','','','box310','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('72','2015-05-28 20:10:16','2015-05-28 20:04:43','bgpic','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/faces_4.jpg','','','','module-paralaxblock-services-layout2-1183036627','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('73','2015-05-28 20:11:40','2015-05-28 20:11:40','bgpic','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/faces_5.jpg','','','','paralaxblock10','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('74','2015-06-05 21:56:40','2015-06-05 21:56:37','color','grey','','','','panels-20150605215631','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('75','2015-06-05 21:57:57','2015-06-05 21:57:57','color','grey','','','','panels-20150605215753','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('76','2015-06-10 20:19:41','2015-06-10 20:19:41','color','grey','','','','module-panels-panels-1277505628','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('77','2015-06-10 20:24:57','2015-06-10 20:21:56','color','default-dark','','','','131','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('78','2015-06-10 20:28:27','2015-06-10 20:28:21','color','default-dark','','','','1311','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('79','2015-06-10 20:33:49','2015-06-10 20:29:29','color','red','','','','1322','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('80','2015-06-10 20:35:16','2015-06-10 20:35:16','color','grey','','','','132','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('81','2015-06-10 20:35:23','2015-06-10 20:35:23','color','red','','','','133','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('82','2015-06-10 20:37:47','2015-06-10 20:37:47','color','light','','','','panels-20150610203721','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('83','2015-06-10 20:52:25','2015-06-10 20:52:23','data-template','default','','','','panels-20150610204346','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('84','2015-06-10 20:53:56','2015-06-10 20:53:56','data-template','gray.php','','','','panels-20150610205312','','','','','panels',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('85','2015-06-10 21:09:43','2015-06-10 21:09:30','data-template','red.php','','','','module-boxes-colorful-boxes593464545','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('86','2015-06-10 21:16:41','2015-06-10 21:16:41','data-template','blue.php','','','','2','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('87','2015-06-10 21:16:45','2015-06-10 21:16:45','data-template','dark.php','','','','3','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('88','2015-06-10 21:16:51','2015-06-10 21:16:51','data-template','darkblue.php','','','','4','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('89','2015-06-10 21:16:55','2015-06-10 21:16:55','data-template','grey.php','','','','5','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('90','2015-06-10 21:17:00','2015-06-10 21:17:00','data-template','purple.php','','','','6','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('91','2015-06-10 21:17:06','2015-06-10 21:17:06','data-template','red.php','','','','8','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('92','2015-06-10 21:17:12','2015-06-10 21:17:10','data-template','yellow.php','','','','7','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('93','2015-06-10 21:25:21','2015-06-10 21:21:37','color','default','','','','module-timeline-timeline-1341441334','','','','','timeline',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('94','2015-06-10 21:25:25','2015-06-10 21:25:25','read_more','Read More','','','','module-timeline-timeline-1341441334','','','','','timeline',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('95','2015-06-10 21:25:31','2015-06-10 21:25:31','character_limit','300','','','','module-timeline-timeline-1341441334','','','','','timeline',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('96','2015-06-10 21:43:04','2015-06-10 21:43:00','data-template','default','','','','module-timeline-timeline-1341441334','','','','','timeline',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('97','2015-06-10 21:51:01','2015-06-10 21:51:01','read_more','Read More','','','','module-timeline-timeline1990349789','','','','','timeline',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('98','2015-06-10 21:51:03','2015-06-10 21:51:03','character_limit','180','','','','module-timeline-timeline1990349789','','','','','timeline',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('99','2015-06-14 12:19:00','2015-06-14 12:18:01','data-template','sidebar.php','','','','15','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('100','2015-06-14 12:21:35','2015-06-14 12:21:13','data-template','search.php','','','','posts15','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('101','2015-06-14 12:21:46','2015-06-14 12:21:44','data-use-from-post','','','','','images15','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('102','2015-06-14 12:23:24','2015-06-14 12:23:22','data-show','thumbnail, title, description','','','','posts15','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('103','2015-06-14 13:52:47','2015-06-14 13:52:42','data-template','sliderbig.php','','','','module-pictures-index2-689369199','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('104','2015-06-14 14:25:53','2015-06-14 14:25:51','data-use-from-post','','','','','bigslider','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('105','2015-06-14 14:58:49','2015-06-14 14:58:46','data-template','sliderbig.php','','','','bigslider','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('106','2015-06-14 14:59:26','2015-06-14 14:59:12','effects_preset','zoom','','','','bigslider','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('107','2015-06-14 15:20:22','2015-06-14 15:10:48','settings','{"0":{"primaryText":"MOE SI E","secondaryText":"AMA MOE","url":"","skin":"revolution1","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/5_2.jpg"},"1":{"primaryText":"awdawdawdawd","secondaryText":"awdawdawdawdawd","url":"","skin":"revolution1","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/6_2.jpg"},"2":{"primaryText":"zymmm","secondaryText":"112","url":"","skin":"revolution1","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/more_features.jpg"}}','','','','bigslider','','','','','magicslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('108','2015-06-14 15:59:08','2015-06-14 15:56:19','settings','{"0":{"primaryText":"Magic Slider","secondaryText":"Nunc blandit malesuada magna nec luctus.","url":"","skin":"revolution1","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/9_3.jpg"},"1":{"primaryText":"Test","secondaryText":"","url":"","skin":"revolution1","images":"{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4_3.jpg"}}','','','','bigslider3','','','','','magicslider',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('109','2015-06-14 15:58:54','2015-06-14 15:58:48','bgpic','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/faces_6.jpg','','','','para116','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('110','2015-06-14 16:01:47','2015-06-14 16:01:10','data-template','product_gallery.php','','','','slider116','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('111','2015-06-14 16:34:12','2015-06-14 16:13:49','bgpic','','','','','paralax216','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('112','2015-06-14 20:07:31','2015-06-14 16:35:16','data-template','default_elite.php','','','','module-pricingtables-services-layout234473920','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('113','2015-06-14 16:36:01','2015-06-14 16:35:51','data-template','default','','','','box110','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('114','2015-06-15 20:15:48','2015-06-14 20:08:24','data-template','default_elite.php','','','','pb2','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('115','2015-06-14 20:09:35','2015-06-14 20:09:35','data-template','default_elite_arc.php','','','','pb3','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('116','2015-06-14 20:15:25','2015-06-14 20:15:21','data-template','flatt.php','','','','pricingtables-20150614201515','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('117','2015-06-14 20:16:18','2015-06-14 20:16:18','data-template','flatt.php','','','','pb5','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('118','2015-06-15 20:17:46','2015-06-15 20:17:46','data-template','default_elite.php','','','','pb4','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('119','2015-06-15 20:27:31','2015-06-15 20:27:31','data-template','default_elite.php','','','','pb213','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('120','2015-06-15 20:45:55','2015-06-15 20:45:54','data-use-from-post','','','','','aboutusslider','','','','','',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('121','2015-06-15 20:56:29','2015-06-15 20:53:01','data-template','product_gallery_multiline.php','','','','picsliderbig','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('122','2015-06-16 15:40:27','2015-06-16 15:40:22','data-template','sliderbig.php','','','','bigslider1','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('123','2015-06-16 16:29:00','2015-06-16 16:28:56','data-template','team.php','','','','paralaxblock-20150616162757','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('124','2015-06-16 16:49:39','2015-06-16 16:36:28','data-template','team.php','','','','paralaxblockaboutus1','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('125','2015-06-16 16:50:23','2015-06-16 16:36:38','bgpic','{SITE_URL}userfiles/media/tarita-lab-microweber-com/uploaded/4.png','','','','paralaxblockaboutus1','','','','','paralaxblock',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('126','2015-06-16 17:13:45','2015-06-16 17:13:45','data-template','darkblue.php','','','','b12','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('127','2015-06-16 17:13:59','2015-06-16 17:13:59','data-template','red.php','','','','b13','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('128','2015-06-16 17:14:11','2015-06-16 17:14:11','data-template','yellow.php','','','','b1','','','','','boxes',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('129','2015-06-16 17:15:00','2015-06-16 17:14:55','data-template','inner.php','','','','2cr22','','','','','pictures',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('130','2015-06-16 17:19:50','2015-06-16 17:18:01','data-template','sidebar2.php','','','','right22','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('131','2015-06-16 17:18:58','2015-06-16 17:18:58','data-template','sidebar2.php','','','','right23','','','','','posts',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('132','2015-06-16 17:38:48','2015-06-16 17:23:42','data-template','pricing_v4.php','','','','pricingtables-20150616172326','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('133','2015-06-16 17:39:34','2015-06-16 17:39:34','data-template','pricing_v4.php','','','','pricingtables-20150616173925','','','','','pricingtables',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('134','2015-06-24 09:28:08','2015-06-24 09:25:03','data-template','columns.php','','','','module-shop-products-shop1415219041','','','','','shop/products',''); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options (id,updated_at,created_at,option_key,option_value,option_key2,option_value2,position,option_group,name,help,field_type,field_values,module,is_system) VALUES('135','2015-06-24 12:54:34','2015-06-24 12:54:34','data-limit','1','','','','module-shop-products-classic-laundry-green-graphic-t-shirt-1547321404','','','','','shop/products',''); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart (id,title,is_active,rel_id,rel_type,updated_at,created_at,price,currency,session_id,qty,other_info,order_completed,order_id,skip_promo_code,created_by,custom_fields_data) VALUES('1','Classic Laundry Green Graphic T-Shirt','','26','content','2015-06-24 09:25:17','2015-06-24 09:25:17','20.0','','df4332150f289922920c6d4be5214cfc19de3ba9','1','','0','','','1','W10='); /* MW_QUERY_SEPERATOR */





REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_shipping (id,updated_at,created_at,is_active,shipping_cost,shipping_cost_max,shipping_cost_above,shipping_country,position,shipping_type,shipping_price_per_size,shipping_price_per_weight,shipping_price_per_item,shipping_price_custom) VALUES('1','2015-05-10 13:19:29','2015-05-10 13:19:29','1','0.0','','','Worldwide','','fixed','','','',''); /* MW_QUERY_SEPERATOR */





